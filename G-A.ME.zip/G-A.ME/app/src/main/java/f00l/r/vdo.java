package f00l.r;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class vdo extends Service {

	private Notification no;
	int seconds=0;
	private View mFloatingView;
    WindowManager.LayoutParams paeams;
	private WindowManager mWindowManager;
	int DISPLAY_WIDTH,DISPLAY_HEIGHT,FPS,BITRATE,density,result,orintation;
	Intent data;
	boolean change_voice;
	public static File tempfile=new File("/storage/emulated/0/G-A.ME/voice.mp3");
	private  MediaProjection mMediaProjection;
    private  VirtualDisplay mVirtualDisplay;
    private  MediaProjectionCallback mMediaProjectionCallback;
    private  MediaRecorder mMediaRecorder;
	private MediaProjectionManager mProjectionManager;

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		no = new Notification.Builder(this, "idch").setSmallIcon(R.drawable.butterfly).setChannelId("idch").setShowWhen(false).build();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			startForeground(1, no, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);} else {startForeground(1, no);}
		Bundle b=intent.getExtras();
		//temp_voice=Environment.getExternalStorageDirectory()+"/G-A.ME/voice.mp3";
		if (b != null) {
			result = b.getInt(Screenrecorder.resulted);
			density = b.getInt(Screenrecorder.dencity);
			data = intent.getParcelableExtra(Screenrecorder.dataest);
			DISPLAY_WIDTH = b.getInt(Screenrecorder.width);
			DISPLAY_HEIGHT = b.getInt(Screenrecorder.height);
			FPS = b.getInt(Screenrecorder.fps);
			BITRATE = b.getInt(Screenrecorder.birate);
			orintation = b.getInt(Screenrecorder.oreo);
			change_voice=b.getBoolean("vc",false);}
		
		mProjectionManager = (MediaProjectionManager) getApplicationContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
		mMediaRecorder = new MediaRecorder();
		
		if (change_voice){
			try {
				Applications.createShells.dtaoutput.writeBytes("amix 'Incall_Music Audio Mixer MultiMedia1' 1");
			} catch (IOException e) {}
			setupVoiceRecorder();} 
			else{
			setupVideoRecorder();}

		mMediaRecorder.start();
		CallonCreate();
		
        return Service.START_STICKY;
	}




    @Override
    public void onCreate() {
        super.onCreate();
		
    }
	void setupVoiceRecorder(){
		try {
			mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL);
			mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
			mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
			mMediaRecorder.setOutputFile(tempfile);
			mMediaRecorder.prepare();
		} catch (IOException e) {} catch (IllegalStateException e) {}
	}
	void setupVideoRecorder() {
		try {
			mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
			mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
			mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
			mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
			mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
			mMediaRecorder.setOutputFile(Environment.getExternalStorageDirectory() + "/G-A.ME/recorded_video" + System.currentTimeMillis() + ".mp4");
			mMediaRecorder.setVideoSize(DISPLAY_WIDTH, DISPLAY_HEIGHT);
			mMediaRecorder.setVideoEncodingBitRate(BITRATE * 1000);
			mMediaRecorder.setVideoFrameRate(FPS);
			mMediaRecorder.setOrientationHint(orintation);
			mMediaRecorder.prepare();
			mMediaProjectionCallback = new MediaProjectionCallback();
			mMediaProjection = createMediaProjection();
			mMediaProjection.registerCallback(mMediaProjectionCallback, null);
			mVirtualDisplay = createVirtualDisplay();
		} catch (IOException e) {} catch (IllegalStateException e) {}
	}

	private MediaProjection createMediaProjection() {
		return mProjectionManager.getMediaProjection(result, data);
    }
    

	

    private VirtualDisplay createVirtualDisplay() {
        return mMediaProjection.createVirtualDisplay("MainActivity",
													 DISPLAY_WIDTH, DISPLAY_HEIGHT, density,
													 DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
													 mMediaRecorder.getSurface(), null, null);
    }

    

    private class MediaProjectionCallback extends MediaProjection.Callback {
        @Override
        public void onStop() {
			mMediaRecorder.stop();
			mMediaRecorder.reset();

            mMediaProjection = null;
            stopScreenSharing();
        }
    }

    private void stopScreenSharing() {
        if (mVirtualDisplay == null) {
            return;
        }
        mVirtualDisplay.release();
        destroyMediaProjection();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        destroyMediaProjection();
		mWindowManager.removeView(mFloatingView);
    }

    private void destroyMediaProjection() {
        if (mMediaProjection != null) {
            mMediaProjection.unregisterCallback(mMediaProjectionCallback);
            mMediaProjection.stop();
            mMediaProjection = null;
        }
    }

	private void CallonCreate() {
		int pa;

		if (Build.VERSION.SDK_INT >= 27) {
			pa = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
		} else {pa = WindowManager.LayoutParams.TYPE_PHONE;}
		mFloatingView = LayoutInflater.from(this).inflate(R.layout.vdo, null);
		paeams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
												WindowManager.LayoutParams.WRAP_CONTENT,
												pa,
												WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
												PixelFormat.TRANSLUCENT);
		paeams.gravity = Gravity.CENTER_VERTICAL | Gravity.RIGHT;
		paeams.x = 50;
		paeams.y = 50;		
		mWindowManager = (WindowManager)getSystemService("window");
		mWindowManager.addView(mFloatingView, paeams);
		LinearLayout view= mFloatingView.findViewById(R.id.vdoLinearLayout);
		view.setClipToOutline(true);
		view.setOnLongClickListener(new View.OnLongClickListener() {

				@Override
				public boolean onLongClick(View view) {
					if(change_voice){
						try {
							Applications.createShells.dtaoutput.writeBytes("aplay -Dhw:0,0 -r 2000hz "+tempfile.getAbsolutePath());
						} catch (IOException e) {}
					}
					mMediaRecorder.stop();
					mMediaRecorder.reset();
					stopScreenSharing();
					stopSelf();
					return false;
				}
			});
		final TextView t=mFloatingView.findViewById(R.id.TextClock);
		final Handler h=	new Handler();
		h.postDelayed(new Runnable(){

				@Override
				public void run() {
					int minutes = (seconds % 3600) / 60; 
					int secs = seconds % 60; 
					String time 
						= String 
						.format(Locale.getDefault(), 
								"%02d:%02d",
								minutes, secs); 
					t.setText(time);
					seconds++;
					h.postDelayed(this, 1000);
				}
			}, 1000);
		view.setOnTouchListener(new View.OnTouchListener(){
				final WindowManager.LayoutParams floatWindowLayoutUpdateParam = paeams; 
				double x; 
				double y; 
				double px; 
				double py; 
				@Override
				public boolean onTouch(View v, MotionEvent event) { 
					switch (event.getAction()) { 
						case MotionEvent.ACTION_DOWN: 
							x = floatWindowLayoutUpdateParam.x; 
							y = floatWindowLayoutUpdateParam.y; 
							px = event.getRawX(); 
							py = event.getRawY(); 
							break; 
						case MotionEvent.ACTION_MOVE: 
							floatWindowLayoutUpdateParam.x = (int) ((x - event.getRawX()) + px); 
							floatWindowLayoutUpdateParam.y = (int) ((y + event.getRawY()) - py); 
							mWindowManager.updateViewLayout(mFloatingView, floatWindowLayoutUpdateParam); 
							break; 
					} return false;}
			});
	}
}
