package f00l.r;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

public class emty extends Activity { 
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		
        
    }

	@Override
	protected void onStart() {
		super.onStart();
		AlertDialog dialog = new AlertDialog.Builder(this)
			.setTitle("Do you want Enable Tweaks ?")
			.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dia, int which) {

						Applications.createShells.gen(emty.this);
				}
			})
			.setNegativeButton("No", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2) {
					getSharedPreferences("twks",MODE_PRIVATE).edit().putBoolean("twks",false).apply();
					finish();
				}
			})
			.create();
		if(!((Activity)this).isFinishing()){dialog.show();}
	}
	
} 
