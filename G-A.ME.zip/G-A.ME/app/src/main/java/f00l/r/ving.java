package f00l.r;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import f00l.r.a;
import java.util.Random;
import android.graphics.Picture;
import android.graphics.drawable.Drawable;
public class ving extends View {
    int du=5,ai,b;
	Paint p;
	Random rendi=new Random();
	boolean is_draw=true;
	Drawable dr;
    public ving(Context context, AttributeSet attrs) {
        super(context, attrs);
		dr = getContext().getResources().getDrawable(R.drawable.butterfly);
    }

    public ving(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
	public ving(Context context) {
		super(context);

    }


	@Override
	protected void onDraw(final Canvas canvas) {
		super.onDraw(canvas);

		p = new Paint(Paint.ANTI_ALIAS_FLAG);
		p.setColor(Color.BLACK);
        p.setStrokeWidth(1.5f);
		p.setStrokeJoin(Paint.Join.ROUND);   
		p.setStrokeCap(Paint.Cap.ROUND);   
		p.setStyle(Paint.Style.STROKE);
		p.setFilterBitmap(true);
		p.setDither(true);
		ai = getHeight() / 2;
		for (int i = 1; i < 22; i++) {
			canvas.drawLine(du * i, (ai + rendi.nextInt(ai)), du * i, (ai - rendi.nextInt(ai)), p);
			if (rendi.nextBoolean()) {if (rendi.nextBoolean()) {b = ai;} else {b = 0;}
				canvas.drawCircle(du * i, b + rendi.nextInt(ai), 1, p);}
		}
		//this block on touc

		if (is_draw) {
			canvas.drawPath(calculatePath(45, getWidth() - 40, getHeight() / 2, canvas), p);
			canvas.drawPath(calculatePath(30, getWidth() - 40, getHeight() / 2, canvas), p);
			p.setColor(Color.DKGRAY);
			p.setPathEffect(new CornerPathEffect(20));
			canvas.drawPath(random_hexagon(getWidth() - 40, ai, 28), p);
			p.setStyle(Paint.Style.FILL);
			p.setColor(a.p);
			canvas.drawPath(random_hexagon(getWidth() - 40, ai, 28), p);
			p.setColor(Color.WHITE);
			p.setTextSize(20);
			p.setTypeface(Typeface.MONOSPACE);
			canvas.drawText(String.valueOf(rendi.nextInt(101)), getWidth() - 50, ai + 6, p);} 
		else {
			dr.setBounds(getWidth()-80,0,getWidth(),getHeight());
			dr.draw(canvas);
		}
		new Handler().postDelayed(new Runnable(){
				@Override
				public void run() {
					invalidate();
				}
			}, 2000);
	}

	Path random_hexagon(int x, int y, int radius) {
		int point1=x - rendi.nextInt(radius),
			pointxy1=rendi.nextInt(radius),pointy1=y + rendi.nextInt(radius),
			pointxy2=rendi.nextInt(radius),pointx2=x + rendi.nextInt(radius),pointxy3=rendi.nextInt(radius),
			pointY3=y - rendi.nextInt(radius),p3=rendi.nextInt(radius);
		Path p= new Path();
		p.moveTo(point1, y);
		p.lineTo(x - pointxy1, y + pointxy1);
		p.lineTo(x, pointy1);
		p.lineTo(x + pointxy2, y + pointxy2);
		p.lineTo(pointx2, y);
		p.lineTo(x + pointxy3, y - pointxy3);
		p.lineTo(x, pointY3);
		p.lineTo(x - p3, y - p3);
		p.lineTo(point1, y);
		return p;
	}

	private Path calculatePath(int radius, int centerX, int centerY, Canvas c) {
		Path hexagonBorderPath=new Path();

		float radiusBorder = radius - 5;    
		float triangleBorderHeight = (float) (Math.sqrt(3) * radiusBorder / 2);
		hexagonBorderPath.moveTo(centerX, centerY + radiusBorder);
		hexagonBorderPath.lineTo(centerX - triangleBorderHeight, centerY + radiusBorder / 2);
		hexagonBorderPath.lineTo(centerX - triangleBorderHeight, centerY - radiusBorder / 2);
		hexagonBorderPath.lineTo(centerX, centerY - radiusBorder);
		hexagonBorderPath.lineTo(centerX + triangleBorderHeight, centerY - radiusBorder / 2);
		hexagonBorderPath.lineTo(centerX + triangleBorderHeight, centerY + radiusBorder / 2);
		hexagonBorderPath.lineTo(centerX, centerY + radiusBorder);

		//c.drawLine(centerX,getHeight(),centerX,0,p);
		//c.drawLine(du*24,centerY,getWidth(),centerY,p);

		//c.drawLine(centerX-triangleBorderHeight,centerY+radiusBorder+2,centerX+triangleBorderHeight,centerY-radiusBorder/2,p);

		return hexagonBorderPath;		
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		is_draw = !is_draw;
		invalidate();
		return super.onTouchEvent(event);
	}

}
