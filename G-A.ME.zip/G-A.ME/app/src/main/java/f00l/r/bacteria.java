package f00l.r;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.WallpaperColors;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import f00l.r.Applications;
import f00l.r.R;
import f00l.r.Tws;
import f00l.r.bacteria;
import java.io.File;
import java.util.Scanner;
import java.util.Set;

public class bacteria extends Activity {
	int ei;
	int Primary_Color;
	public static int text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.xl);
		final TextView devid=findViewById(R.id.devicetex);
		final String App_name=getSharedPreferences("a", MODE_PRIVATE).getString("2", "");
		final ImageView iio=findViewById(R.id.appinc);
		final RadioGroup rg=findViewById(R.id.xlRadioGroup12);
		final RadioButton batry=findViewById(R.id.xlbattrymode);
		final RadioButton aimode=findViewById(R.id.xlaimode);
		final RadioButton smooth=findViewById(R.id.xlsmoothmode);
		final RadioButton gaming=findViewById(R.id.xlgamingmode);
		final ImageView logo=findViewById(R.id.xlImageView1);
		final TextView name=findViewById(R.id.xlTextView3);
		final SharedPreferences modp=getSharedPreferences("mod", MODE_PRIVATE);
		final ImageView i=findViewById(R.id.xlImageView);
		final FrameLayout fl =findViewById(R.id.xlFrameLayout);
		final Button twst=findViewById(R.id.tweaks);
		final Bitmap b=((BitmapDrawable)getWallpaper()).getBitmap();
		final Bitmap bb=blur(this, b);
		Primary_Color = getDominantColor(b);
		text = getContrastColor(Primary_Color);
		twst.setTextColor(Primary_Color);
		twst.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		final TextView driver=findViewById(R.id.driverstat);
		try {String s=new Scanner(new File(Environment.getExternalStorageDirectory() + "/G-A.ME/status")).nextLine();driver.setText(s);} catch (Exception e) {}
		//final Button install_shortcut=findViewById(R.id.Install_shortcut);
		final Button panel_setting=findViewById(R.id.xlPanel_set);
		final Button screen_rec =findViewById(R.id.xlSreen_rec);
		final Button misv=findViewById(R.id.xlMisc);
		
		int Seccondary_Color=WallpaperColors.fromBitmap(b).getSecondaryColor().toArgb();
		
		panel_setting.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		screen_rec.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		misv.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		if (text == Color.BLACK) {setTheme(R.style.AppThemeWhite);} else {setTheme(R.style.AppTheme);}

		int lineh=panel_setting.getLineHeight() * 3;

		Drawable window=getResources().getDrawable(R.drawable.asus_photocollage, getTheme());
		Drawable vcamr=getResources().getDrawable(R.drawable.kwai, getTheme());
		Drawable labb=getResources().getDrawable(R.drawable.b_maniac, getTheme());

		window.setBounds(0, 0, lineh, lineh);
		vcamr.setBounds(0, 0, lineh, lineh);
		labb.setBounds(0, 0, lineh, lineh);

		SpannableStringBuilder sp=new SpannableStringBuilder("Panel Settings ");
		sp.setSpan(new ImageSpan(window), sp.length() - 1, sp.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableStringBuilder sp1=new SpannableStringBuilder("Screen Recording ");
		sp1.setSpan(new ImageSpan(vcamr), sp1.length() - 1, sp1.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		SpannableStringBuilder sp2=new SpannableStringBuilder("Misc.         ");
		sp2.setSpan(new ImageSpan(labb), sp2.length() - 1, sp2.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);

		panel_setting.setText(sp, TextView.BufferType.SPANNABLE);
		screen_rec.setText(sp1, TextView.BufferType.SPANNABLE);
		misv.setText(sp2, TextView.BufferType.SPANNABLE);

		panel_setting.setTextColor(text);
		misv.setTextColor(text);
		screen_rec.setTextColor(text);
		if (Build.HARDWARE.startsWith("mt") && driver.getText().toString().isEmpty()) {driver.setText(" MTK+");} else {driver.setText(" Non MTK mode");}
		final TextView dena=findViewById(R.id.xlTextView1);
		getWindow().getDecorView().setSystemUiVisibility(
			View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);


		//Ui Tweaks####

		if (!App_name.isEmpty()) {try {
				iio.setImageDrawable(getPackageManager().getApplicationIcon(App_name));
			} catch (PackageManager.NameNotFoundException e) {}}
		final SpannableString c=new SpannableString(Build.BRAND.toUpperCase());
		c.setSpan(new UnderlineSpan(), Build.BRAND.length() - (Build.BRAND.length() - 3), Build.BRAND.length(), 0);
		//experimental 
		devid.setTextColor(Seccondary_Color);
		devid.getBackground().setColorFilter(Primary_Color,PorterDuff.Mode.MULTIPLY);
		devid.setShadowLayer(51, 1, 1, WallpaperColors.fromBitmap(b).getTertiaryColor().toArgb());
		rg.setClipToOutline(true);
		if (modp.getBoolean("bt", false)) {batry.setChecked(true);batry.setBackgroundResource(R.drawable.Tile_sec);
			batry.getBackground().setColorFilter(Color.GREEN, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);}
		if (modp.getBoolean("sm", false)) {smooth.setChecked(true);smooth.setBackgroundResource(R.drawable.Tile_sec);
			smooth.getBackground().setColorFilter(Color.YELLOW, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_IN);}
		if (modp.getBoolean("gm", false)) {gaming.setChecked(true);
			gaming.setBackgroundResource(R.drawable.Tile_sec);
			gaming.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);}
		if (modp.getBoolean("ai", true)) {aimode.setChecked(true);
			aimode.setBackgroundResource(R.drawable.Tile_sec);
			aimode.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.SRC_IN);}
		findViewById(R.id.xlLinearLayout1).getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.SRC_IN);
		driver.setTextColor(Seccondary_Color);
		logo.setColorFilter(Seccondary_Color);
		name.setTextColor(Seccondary_Color);
		findViewById(R.id.xlLinearLayout2).getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		TextView tvf=findViewById(R.id.xlTextView2);
		tvf.setTextColor(Seccondary_Color);
		panel_setting.setTextColor(text);
		screen_rec.setTextColor(text);
		misv.setTextColor(text);
		findViewById(R.id.xldec5).getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);
		ei = getinvertcol(Primary_Color);
		dena.setTextColor(ei);
		dena.setText(c);
		findViewById(R.id.xlRelativeLayouty).setBackground(new BitmapDrawable(getResources(), bb));
		fl.setClipToOutline(true);
		findViewById(R.id.xlView1).getBackground().setColorFilter(Color.BLACK, PorterDuff.Mode.DARKEN);
		i.setImageDrawable(getWallpaper());
		final Handler h = new Handler();
		h.post(new Runnable() {
				@Override
				public void run() {
					try {
						devid.setText("User: " + Build.USER + "\nAndroid " + Build.VERSION.RELEASE + "\nCPU ABI : " + Build.CPU_ABI + "\nHardware: " + Build.HARDWARE + "\nBootloader " + Build.BOOTLOADER + "\nType: " + Build.TYPE + "\nID: " + Build.ID + freem());
					} catch (Exception e) {}
					h.postDelayed(this, 5000);
				}
			});

		// InterAction ###
		logo.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivity(new Intent(bacteria.this, MainActivity.class));
				}
			});


		iio.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					Intent i= getPackageManager().getLaunchIntentForPackage(App_name);
					i.setFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
					ActivityOptions ao = ActivityOptions.makeBasic();
					Rect rect = new Rect(0, 0 , 100, 100);
					ActivityOptions bounds = ao.setLaunchBounds(rect);
					startActivity(i, bounds.toBundle());
				}
			});
		panel_setting.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivity(new Intent(bacteria.this, Panel_Setting.class));
				}
			});
		screen_rec.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivity(new Intent(bacteria.this, screen_rec.class));
				}
			});
		misv.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivity(new Intent(bacteria.this, misc.class));
				}
			});

		findViewById(R.id.xlButton2).setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					Applications.createShells.telg(bacteria.this);
				}
			});

//					install_shortcut.setOnClickListener(new View.OnClickListener() {
//
//							@Override
//							public void onClick(View view) {
//
//							}
//						});

		twst.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					startActivity(new Intent(bacteria.this, Tws.class));
				}
			});



		aimode.setOnLongClickListener(new View.OnLongClickListener() {

				@Override
				public boolean onLongClick(View view) {
					startActivity(new Intent(bacteria.this, deti.class));
					return true;
				}
			});

		aimode.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					Toast.makeText(getApplication(), "AI mode . Reboot will revert all changes", Toast.LENGTH_SHORT).show();
					modp.edit().putBoolean("ai", p2).apply();
					if (p2) {new Handler().post(new Runnable(){

								@Override
								public void run() {
									try {
										Applications.createShells.gen(bacteria.this);appon.aiload(bacteria.this);
									} catch (Exception e) {}
								}
							});
						p1.setBackgroundResource(R.drawable.Tile_sec);
						p1.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Primary_Color, PorterDuff.Mode.SRC_IN);

					} else {p1.setBackgroundColor(Color.TRANSPARENT);}
				}
			});

		batry.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					Toast.makeText(getApplication(), "Reboot wil revert all changes!", Toast.LENGTH_SHORT).show();
					modp.edit().putBoolean("bt", p2).apply();
					if (p2) {new Handler().post(new Runnable(){

								@Override
								public void run() {
									try {
										Applications.createShells.battry(bacteria.this);
									} catch (Exception e) {}
									try {
										Shell.sudo("echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
									} catch (Shell.ShellException e) {}
								}
							});
						p1.setBackgroundResource(R.drawable.Tile_sec);
						p1.getBackground().setColorFilter(Color.GREEN, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.GREEN, PorterDuff.Mode.SRC_IN);
					} else {p1.setBackgroundColor(Color.TRANSPARENT);}
				}
			});

		smooth.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					Toast.makeText(getApplication(), "Reboot will revert all changes", Toast.LENGTH_SHORT).show();
					modp.edit().putBoolean("sm", p2).apply();
					if (p2) {new Handler().post(new Runnable(){

								@Override
								public void run() {
									try {
										Applications.createShells.balance(bacteria.this, true);
									} catch (Exception e) {}
								}
							});
						p1.setBackgroundResource(R.drawable.Tile_sec);
						p1.getBackground().setColorFilter(Color.YELLOW, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_IN);
					} else {p1.setBackgroundColor(Color.TRANSPARENT);}
				}
			});

		gaming.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					modp.edit().putBoolean("gm", p2).apply();
					if (p2) {new Handler().post(new Runnable(){

								@Override
								public void run() {

									Applications.createShells.perfom(bacteria.this);

									try {
										Shell.sudo("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
									} catch (Shell.ShellException e) {}
								}
							});
						p1.setBackgroundResource(R.drawable.Tile_sec);
						p1.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.MULTIPLY);rg.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
					} else {p1.setBackgroundColor(Color.TRANSPARENT);}
				}
			});

	}


	@Override
	protected void onResume() {
		super.onResume();


		getWindow().getDecorView().setSystemUiVisibility(
			View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

	}

	public static int getDominantColor(Bitmap bitmap) {
		int p=WallpaperColors.fromBitmap(bitmap).getPrimaryColor().toArgb();
		return p;
	}

	public String freem() throws Exception {
		Scanner scanner = new Scanner(new File("/proc/meminfo"));
		StringBuffer stringBuffer = new StringBuffer();
		int i=0;
		while (scanner.hasNext()) {
			if (i >= 10) {break;}
			stringBuffer.append(new StringBuffer().append("\n").append(scanner.nextLine()).toString());
			i++;
		}
		return String.valueOf(stringBuffer);
	}
	private int getinvertcol(int colour) {
		int	red = ((colour & 0xC0) >> 6) * 64; 
		int	green = ((colour & 0x30) >> 4) * 64;
		int	blue = ((colour & 0x0C) >> 2) * 64;

		int	invertedRed   = 255 - red;
		int	invertedGreen = 255 - green;
		int	invertedBlue  = 255 - blue;
		return 
			Color.argb(10000000000000000f, invertedRed, invertedGreen, invertedBlue);
	}
	public static int getContrastColor(int colorIntValue) {
		int red = Color.red(colorIntValue);
		int green = Color.green(colorIntValue);
		int blue = Color.blue(colorIntValue);
		double lum = (((0.299 * red) + ((0.587 * green) + (0.114 * blue))));
		return lum > 186 ? 0xFF000000 : 0xFFFFFFFF;
	}
	private long firstBackTime;

	@Override
	public void onBackPressed() {

		if (System.currentTimeMillis() - firstBackTime > 2000) {
			Toast.makeText(this, "preess back again to exit", Toast.LENGTH_SHORT).show();
			firstBackTime = System.currentTimeMillis();
			return;
		}

		super.onBackPressed();
	}



	private static final float BITMAP_SCALE = 0.1f;
	private static final float BLUR_RADIUS = 20.5f;

	public static Bitmap blur(Context context, Bitmap image) {
		int width = Math.round(image.getWidth() * BITMAP_SCALE);
		int height = Math.round(image.getHeight() * BITMAP_SCALE);

		Bitmap inputBitmap = Bitmap.createScaledBitmap(image, width, height, false);
		Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);

		RenderScript rs = RenderScript.create(context);
		ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
		Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
		Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
		theIntrinsic.setRadius(BLUR_RADIUS);
		theIntrinsic.setInput(tmpIn);
		theIntrinsic.forEach(tmpOut);
		tmpOut.copyTo(outputBitmap);

		return outputBitmap;
	}


	public static boolean isinstalled(String pkg) {
		try {
			Applications.getAppContext().getPackageManager().getPackageInfo(pkg, 0);
			return true;
		} catch (PackageManager.NameNotFoundException e) {return false;}}
	static Set<String> set1;

	public void github(View v) {
		Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/0-Whoami/G-A.ME/"));
		startActivity(i);
	}

	public void shortcut(View v) {
		ShortcutManager sht=(ShortcutManager)getSystemService(SHORTCUT_SERVICE);
		if (sht.isRequestPinShortcutSupported()) {
			String appname=getString(R.string.app_name);
			Intent i=new Intent(this,bacteria.class).setAction("open").putExtra("",true);
			ShortcutInfo.Builder shityinfo=new ShortcutInfo.Builder(this, "open");
			shityinfo.setShortLabel(appname)
				.setLongLabel(appname)
				.setIntent(i)
				.setIcon(Icon.createWithResource(this, R.drawable.butterfly));

			ShortcutInfo shitinfo=shityinfo.build();
			sht.requestPinShortcut(shitinfo, null);
		} else {Toast.makeText(getApplication(), "ShortCut Not Supported", Toast.LENGTH_SHORT).show();}
	}
}

