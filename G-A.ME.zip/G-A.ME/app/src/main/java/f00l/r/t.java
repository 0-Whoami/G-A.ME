package f00l.r;

import android.accessibilityservice.AccessibilityService;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class t extends TileService {
AccessibilityService acs = new ass();
	@Override
	public void onTileAdded() {
		super.onTileAdded();
		startActivity(new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
		getQsTile().setState(Tile.STATE_INACTIVE);
		t.requestListeningState(this,new ComponentName(this,t.class));
	}
	private boolean isMyServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public void onStartListening() {
		super.onStartListening();
		updatetile();  
		
	}

	@Override
	public void onClick() {
		super.onClick();
		if(getSharedPreferences("a",MODE_PRIVATE).getBoolean("mans",true)){if (isMyServiceRunning(a.class)) {stopForeground(true);
						try {
								this.stopService(
									new Intent(
										this,
										a.class
									)
								);
							} catch (Exception ex) {
									}
						
		acs.disableSelf();} else {
			startForegroundService(new Intent(t.this, a.class));//final MediaPlayer mp=new MediaPlayer().create(this, R.drawable.abnd);//try{mp.start();}catch(Exception e){}
			}
			updatetile();
	}}
			private void updatetile(){
				Tile tile=getQsTile();
				tile.updateTile();
				if(!isMyServiceRunning(a.class)){tile.setState(Tile.STATE_ACTIVE);tile.setLabel("On ️🎐");}else{tile.setState(Tile.STATE_INACTIVE);tile.setLabel("Off 🎐");}
			}
}
