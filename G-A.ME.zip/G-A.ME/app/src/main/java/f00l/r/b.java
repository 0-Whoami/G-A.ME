package f00l.r;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

public class b extends Service {
    WindowManager wind;
	WebView w;
	LinearLayout exp;
	WindowManager.LayoutParams paeams ;
	View col;
	private View l;
    @Override
    public IBinder onBind(Intent intent) {      
        return null;
    }
	public b(){
	}

    

	@Override
	public void onDestroy() {
		super.onDestroy();
		if(wind!=null){wind.removeView(l);}
	}

	@Override
	public void onCreate() {
		try{
			super.onCreate();

			if(Settings.canDrawOverlays(this)){
				int pa;
				l = LayoutInflater.from(b.this).inflate(R.layout.b, null);
				w = l.findViewById(R.id.web);
				w.clearCache(true);
				w.setWebViewClient(new WebViewClient());
				w.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
				w.getSettings().setJavaScriptEnabled(true);
				w.getSettings().setAllowContentAccess(true);
				w.getSettings().setAllowFileAccess(true);
				w.getSettings().setDatabaseEnabled(true);
				w.getSettings().setDomStorageEnabled(true);
				w.getSettings().setUseWideViewPort(false);
				w.getSettings().setSupportZoom(true);
				w.getSettings().setBuiltInZoomControls(true);
				w.getSettings().setUserAgentString(new WebView(b.this).getSettings().getUserAgentString());
				w.getSettings().setDisplayZoomControls(false);
				w.setScrollBarStyle(33554432);
				w.setScrollbarFadingEnabled(true);
				w.getSettings().enableSmoothTransition();
				w.getSettings().getAllowUniversalAccessFromFileURLs();
				w.getSettings().getCacheMode();
				w.getSettings().getBlockNetworkLoads();
				w.getSettings().getMediaPlaybackRequiresUserGesture();
				w.getSettings().getOffscreenPreRaster();
				w.loadUrl("https://www.google.com");
				w.measure(w.getWidth(), w.getHeight());
				w.clearView();
				w.getSettings().setLoadWithOverviewMode(true);
				w.getSettings().setLoadsImagesAutomatically(true);
				if (Build.VERSION.SDK_INT >= 19) {
					w.setLayerType(View.LAYER_TYPE_HARDWARE, null);
				}       
				else {
					w.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
				}
				if(Build.VERSION.SDK_INT>=27) {
					pa = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
				}else{pa = WindowManager.LayoutParams.TYPE_PHONE;}
				paeams = new WindowManager.LayoutParams(450,
				400,
				pa,
				WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
				PixelFormat.TRANSLUCENT);
				wind = (WindowManager)getSystemService("window");
				wind.addView(l, paeams);
				col = l.findViewById(R.id.bclps);
				exp = l.findViewById(R.id.bexp);
				exp.setClipToOutline(true);
				l.findViewById(R.id.bButton1).setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {
						stopSelf();
					}
				});
				l.findViewById(R.id.bButton2).setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {if(w.canGoForward()){w.goForward();}
					}
				});
				l.findViewById(R.id.bButton3).setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {if(w.canGoBack()){w.goBack();}
					}
				});
				l.findViewById(R.id.bButton).setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {vi();
					}
				});
				l.findViewById(R.id.bclps).setOnTouchListener(new View.OnTouchListener(){
					int x;
					int y;
					int hei;
					int wid;
					@Override
					public boolean onTouch(View p1,MotionEvent p2) {

						switch(p2.getAction()){
								case MotionEvent.ACTION_DOWN:
								x = (int)p2.getRawX();
								y = (int)p2.getRawY();
								hei = paeams.y;
								wid = paeams.x;
								return true;
								case MotionEvent.ACTION_UP:
								vi();
								return true;
								case MotionEvent.ACTION_MOVE:
								paeams.y = hei+((int)(p2.getRawY()-y));
								paeams.x = wid+((int)(p2.getRawX()-x));
								wind.updateViewLayout(l, paeams);
								return true;

						}
						return false;
					}
				});
				l.findViewById(R.id.bTextView1234).setOnTouchListener(new View.OnTouchListener(){
					int x;
					int y;
					int hei;
					int wid;
					@Override
					public boolean onTouch(View p1,MotionEvent p2) {

						switch(p2.getAction()){
								case MotionEvent.ACTION_DOWN:
								x = (int)p2.getRawX();
								y = (int)p2.getRawY();
								hei = paeams.y;
								wid = paeams.x;
								return true;
								case MotionEvent.ACTION_MOVE:
								paeams.y = hei+((int)(p2.getRawY()-y));
								paeams.x = wid+((int)(p2.getRawX()-x));
								wind.updateViewLayout(l, paeams);
								return true;

						}
						return false;
					}
				});
				l.findViewById(R.id.bButtonres).setOnTouchListener(new View.OnTouchListener(){
					int x;
					int y;
					int hei;
					int wid;
					@Override
					public boolean onTouch(View p1,MotionEvent p2) {

						switch(p2.getAction()){
								case MotionEvent.ACTION_DOWN:
								x = (int)p2.getRawX();
								y = (int)p2.getRawY();
								hei = paeams.height;
								wid = paeams.width;
								return true;
								case MotionEvent.ACTION_MOVE:
								paeams.height = hei+((int)(p2.getRawY()-y));
								paeams.width = wid+((int)(p2.getRawX()-x));
								if(hei+((int)(p2.getRawY()-y))<50){paeams.height = 50;}
								if(wid+((int)(p2.getRawX()-x))<70){paeams.width = 70;}
								wind.updateViewLayout(l, paeams);
								return true;

						}
						return false;
					}
				});
			}}catch(Exception e){}}
	public void vi(){
		if(col.getVisibility()==View.VISIBLE){col.setVisibility(View.GONE);exp.setVisibility(View.VISIBLE);keyi();}else{col.setVisibility(View.VISIBLE);exp.setVisibility(View.GONE);keyd();}
	}
	private void keyi(){paeams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;wind.updateViewLayout(l, paeams);}
	private void keyd(){paeams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;wind.updateViewLayout(l, paeams);}
	
	@Override
	public int onStartCommand(Intent intent,int flags,int startId) {
		Notification no=new Notification.Builder(this, "idch").setSmallIcon(R.drawable.butterfly).setChannelId("idch").setShowWhen(false).build();
		startForeground(1, no);
			return START_FLAG_RETRY;
	}
}
