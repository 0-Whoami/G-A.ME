package f00l.r;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.Service;
import android.app.WallpaperColors;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import f00l.r.new_a;
import f00l.r.pee;
import java.util.List;
import java.io.IOException;
import java.io.File;

public class a extends Service {
	public static Notification no;
	public View collapsedView;
	String s="idch";
	public View mFloatingView;
	private WindowManager mWindowManager;
	WindowManager.LayoutParams paeams;
	public static int p;
	int colorFrom;
	public static boolean act=false;
	public static LinearLayout container;
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onRebind(Intent intent) {
		super.onRebind(intent);
		stopForeground(true);
	}

	@Override
	public boolean onUnbind(Intent intent) {
		startCommand();
		return true;
	}

	public a() {}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {

		if (intent == null) {
			return START_NOT_STICKY;
		}

		return START_STICKY;
	}

	private void startCommand() {no = new Notification.Builder(this, this.s).setSmallIcon(R.drawable.butterfly).setChannelId("idch").setShowWhen(false).build();
		startForeground(1, no);
	}
	@Override
	public void onCreate() {
		super.onCreate();
		act=true;
		startCommand();
		int pa;
		final View layout = LayoutInflater.from(a.this).inflate(R.layout.tost, null);
		pee.omlet(a.this, layout);
		final ProgressBar po= layout.findViewById(R.id.tostProgressBar);
		final Handler wtf=new Handler();
		wtf.postDelayed(new Runnable(){
				@Override
				public void run() {
					 ObjectAnimator.ofInt(po, "progress", 100)
						.setDuration(2000).start();
				}
			},2000);
		
		if (Build.VERSION.SDK_INT >= 27) {
			pa = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
		} else {pa = WindowManager.LayoutParams.TYPE_PHONE;}
		mFloatingView = LayoutInflater.from(a.this).inflate(R.layout.a, null);

		paeams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
												WindowManager.LayoutParams.WRAP_CONTENT,
												pa,
												WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
												PixelFormat.TRANSLUCENT);
		paeams.gravity = Gravity.TOP | kwin();
		paeams.x = 0;
		paeams.y = 0;	
		p=WallpaperColors.fromDrawable(getWallpaper()).getSecondaryColor().toArgb();
		mWindowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
		mWindowManager.addView(mFloatingView, paeams);
		collapsedView = mFloatingView.findViewById(R.id.coll);
		colorFrom=getContrastColor(p);
		final View rt=mFloatingView.findViewById(R.id.aRelativeLayout);
		Runnable glow_effext=new Runnable(){

			@Override
			public void run() {
				
				ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorFrom, p);
				colorAnimation.setDuration(4000);

				colorAnimation.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {

						@Override
						public void onAnimationUpdate(ValueAnimator animator) {
							rt.getBackground().setColorFilter((int) animator.getAnimatedValue(), PorterDuff.Mode.MULTIPLY);
						}

					});
				colorAnimation.start();
		
			}
		};
		wtf.postDelayed(glow_effext,3000);
		container=new LinearLayout(this);
		container.setOrientation(LinearLayout.VERTICAL);
		wtf.postDelayed(new Runnable(){

				@Override
				public void run() {
					addtocontainer();
				}
			}, 100);
		collapsedView.setOnTouchListener(new View.OnTouchListener(){

				@Override
				public boolean onTouch(View view, MotionEvent event) {
					Intent I= new Intent(a.this, new_a.class);
					startForegroundService(I);
					return true;
				}
			});
			
		
	}

//	@Override
//	public void onConfigurationChanged(@NonNull Configuration newConfig) {
//		super.onConfigurationChanged(newConfig);
//		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//			collapsedView.setY(150);
//		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
//			collapsedView.setY(1000);
//		}
//	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		act=false;
		try {
			Applications.createShells.dtaoutput.writeBytes("amix 'Incall_Music Audio Mixer MultiMedia1' 0 ");
			vdo.tempfile.delete();
		} catch (IOException e) {}
		try { android.provider.Settings.System.putInt(getContentResolver(),
													  android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, 
													  android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC);
			mWindowManager.removeView(mFloatingView);         
			((ViewGroup)mFloatingView.getParent()).removeAllViews(); 
			mFloatingView.invalidate(); 
			relese();
		} catch (Exception e) { }
		stopSelf();
	}
	private int kwin() {
		if (getSharedPreferences("a", MODE_PRIVATE).getBoolean("4", false)) {return Gravity.RIGHT;} else {return Gravity.LEFT;}
	}

	

	void relese() {
		paeams = null;
		mWindowManager = null;
		stopSelf();
	}
	public static int getContrastColor(int colorIntValue) {
		int red = Color.red(colorIntValue);
		int green = Color.green(colorIntValue);
		int blue = Color.blue(colorIntValue);
		double lum = (((0.299 * red) + ((0.587 * green) + (0.114 * blue))));
		return lum > 186 ? 0xFF000000 : 0xFFFFFFFF;
	}
	
	private void addtocontainer() {
		PackageManager pm =getPackageManager();
		Intent i=new Intent(Intent.ACTION_MAIN);
		i.addCategory(Intent.CATEGORY_LAUNCHER);
		List<ResolveInfo> packages= pm.queryIntentActivities(i, 0);
		for (final ResolveInfo s:packages) {
			ImageButton img=new ImageButton(this);
			img.setAdjustViewBounds(true);
			img.setScaleType(ImageButton.ScaleType.FIT_CENTER);
			img.setImageDrawable(appicon(s.activityInfo.packageName));
			img.setBackground(null);
			img.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						pee.laf(s.activityInfo.packageName, a.this);
					}
				});
			container.addView(img);
		}
	}
	Drawable appicon(String s) {
		try {
			Drawable appic= getPackageManager().getApplicationIcon(s);
			return appic;
		} catch (Exception e) {}
		return null;
	}
//	private boolean isPotrait(){
//		boolean currentRatation=true;
//		int rot=mWindowManager.getDefaultDisplay().getRotation();
//		if (Surface.ROTATION_0 == rot) {
//			currentRatation = true;
//		} else if(Surface.ROTATION_180 == rot) {
//			currentRatation = true;
//		} else if(Surface.ROTATION_90 == rot) {
//			currentRatation = false;
//		} else if(Surface.ROTATION_270 == rot) {
//			currentRatation = false;
//		}
//		return currentRatation;
//	}
}
