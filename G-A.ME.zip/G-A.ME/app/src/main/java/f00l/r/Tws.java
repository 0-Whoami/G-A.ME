package f00l.r;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperColors;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Locale;
import f00l.r.Shell.ShellException;

public class Tws extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tws);
		//if(bacteria.text==Color.BLACK){setTheme(R.style.AppThemeWhite);}else{setTheme(R.style.AppTheme);}
		getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
		final SharedPreferences getSh=getSharedPreferences("twks",MODE_PRIVATE);
		final Switch ats=findViewById(R.id.twsSwitchAlt);
		final TextView logs=findViewById(R.id.logs_show);
		Switch btws=findViewById(R.id.twsSwitchblt);
		Button cb =findViewById(R.id.twsButtonche);
		Switch dub=findViewById(R.id.debugging_switch_toogle);
		Bitmap back= bacteria.blur(Tws.this,((BitmapDrawable)getWallpaper()).getBitmap());
		getWindow().setBackgroundDrawable(new BitmapDrawable(getResources(),back));
		int p=WallpaperColors.fromDrawable(getWallpaper()).getPrimaryColor().toArgb();
		
		ats.setChecked(getSh.getBoolean("twks",true));
		dub.setChecked(getSh.getBoolean("dbg",false));
		cb.getBackground().setColorFilter(p,PorterDuff.Mode.SRC);
		dub.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					if(p2){Toast.makeText(getApplication(), "Logging started on "+startdebug(Tws.this), Toast.LENGTH_SHORT).show();}else{stopdebug(Tws.this);}
				}
			});
		ats.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					getSh.edit().putBoolean("twks",p2).apply();
					if(!p2){AlertDialog dialog = new AlertDialog.Builder(Tws.this)
						.setTitle("Please Reboot")
						.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dia, int which) {
								try {
									Shell.sudo("Reboot");
								} catch (Shell.ShellException e) {}
							}
						})
							.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface p1, int p2) {
									getSh.edit().putBoolean("twks",true).apply();ats.setChecked(true);
									}
							})
						.create();
						dialog.setOnCancelListener(new DialogInterface.OnCancelListener(){

								@Override
								public void onCancel(DialogInterface p1) {getSh.edit().putBoolean("twks",true).apply();ats.setChecked(true);
								}
							});
                    dialog.show();}
				}
			});
			findViewById(R.id.twsScrollView).getBackground().setColorFilter(p,PorterDuff.Mode.MULTIPLY);
		btws.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
				if(p2){backupBuildProp(Tws.this);}else{restoreBuildProp(Tws.this);}
					
				}
			});
		try {
			logs.setText(Shell.exec("logcat -d"));
		} catch (Shell.ShellException e) {}
    }

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
	}
  public static  void backupBuildProp(Context context){
		String path=context.getApplicationInfo().dataDir;
		if(!new File(path).exists()){try {
			Shell.sudo("cat /system/build.prop > "+path+"/build.backup");
		} catch (Shell.ShellException e) {}}
	}
public static void restoreBuildProp(Context context){
		try {String path=context.getApplicationInfo().dataDir;
			Shell.sudo("cat "+path+"/build.backup > /system/build.prop");
		} catch (Shell.ShellException e) {}
	}
	void dex2oat(){}
	
	public static String startdebug(Context c){
		SimpleDateFormat df=new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss",Locale.getDefault());
	String date=df.format(new Date());
		try {
			Runtime.getRuntime().exec("logcat -f "+Environment.getExternalStorageDirectory()+"/G-A.ME/G-A.ME_log_"+date+".txt");
		} catch (IOException e) {}
		Debug.startMethodTracing(Environment.getExternalStorageDirectory() + "/G-A.ME/G-A.ME trace -     " + date + "        ");
	c.getSharedPreferences("twks",c.MODE_PRIVATE).edit().putBoolean("dbg",true);
	return date;}
	public static void stopdebug(Context c){
		try {
			Runtime.getRuntime().exec("pkill -n logcat");
		} catch (IOException e) {}
		Debug.stopMethodTracing();c.getSharedPreferences("twks", c.MODE_PRIVATE).edit().putBoolean("dbg", false);}
}
