package f00l.r;
 
import android.app.Activity;
import android.app.WallpaperColors;
import android.app.WallpaperManager;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class deti extends Activity { 
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detai);
		
		final WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
		final Drawable wallpaperDrawable = wallpaperManager.getDrawable();
		Bitmap back= bacteria.blur(deti.this,((BitmapDrawable)wallpaperDrawable).getBitmap());
		getWindow().setBackgroundDrawable(new BitmapDrawable(getResources(),back));
		final int p=WallpaperColors.fromDrawable(wallpaperDrawable).getPrimaryColor().toArgb();
		final int s=WallpaperColors.fromDrawable(wallpaperDrawable).getTertiaryColor().toArgb();
		int color=bacteria.getContrastColor(p);
        RadioGroup rg=findViewById(R.id.detaiRadioGroup);
		rg.setClipToOutline(true);
		rg.getBackground().setColorFilter(p,PorterDuff.Mode.SRC);
		RadioButton bat,ai,per;
		bat=findViewById(R.id.detaiRadioButton);
		ai=findViewById(R.id.detaiRadioButton1);
		per=findViewById(R.id.detaiRadioButton2);
	
		if(color==Color.BLACK){setTheme(R.style.AppThemeWhite);}else{setTheme(R.style.AppTheme);}
		SharedPreferences sers=getSharedPreferences("deti",MODE_PRIVATE);
		final SharedPreferences.Editor se=sers.edit();
		boolean batru=sers.getBoolean("bat",false);
		boolean aitru=sers.getBoolean("ai",true);
		boolean pertru=sers.getBoolean("per",false);
		bat.setChecked(batru);
		ai.setChecked(aitru);
		per.setChecked(pertru);
		ai.setTextColor(color);
		per.setTextColor(color);
		bat.setTextColor(color);
		if(batru){bat.setBackgroundColor(s);}else if(aitru){ai.setBackgroundColor(s);}else{
			per.setBackgroundColor(s);
		}
		bat.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
				se.putBoolean("bat",p2).apply();
				se.putInt("thresh",1).apply();
				if(p2){p1.setBackgroundColor(s);}else{p1.setBackgroundColor(Color.TRANSPARENT);}
				}
			});
		ai.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					se.putBoolean("ai",p2).apply();se.putInt("thresh",0).apply();
					if(p2){p1.setBackgroundColor(s);}else{p1.setBackgroundColor(Color.TRANSPARENT);}}
			});
		per.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

				@Override
				public void onCheckedChanged(CompoundButton p1, boolean p2) {
					se.putBoolean("per",p2).apply();se.putInt("thresh",-1).apply();
					if(p2){p1.setBackgroundColor(s);}else{p1.setBackgroundColor(Color.TRANSPARENT);}}
			});
    }

	@Override
	protected void onResume() {
		super.onResume();
		getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
	}
	
} 
