package f00l.r;
 
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.View;
import android.widget.EditText;

public class screen_rec extends Activity { 
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rec_layout);
		if(bacteria.text==Color.BLACK){setTheme(R.style.AppThemeWhite);}else{setTheme(R.style.AppTheme);}
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        final EditText sh=findViewById(R.id.xlEditText3);
        final EditText sw=findViewById(R.id.xlEdw);
        final EditText sb=findViewById(R.id.xlEditText5);
        final EditText st=findViewById(R.id.xlEditText4);
         
        final Bitmap b=((BitmapDrawable)getWallpaper()).getBitmap();
        final Bitmap bb=bacteria.blur(this,b);
        Drawable d=new BitmapDrawable(getResources(),bb);
        SharedPreferences sp=getSharedPreferences("rec",MODE_PRIVATE);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();display.getRealSize(size);
        final int width =size.x;
	    final int height =size.y;
        sh.setText(String.valueOf(sp.getInt("resh",height)));
        sw.setText(String.valueOf(sp.getInt("resw",width)));
        sb.setText(String.valueOf(sp.getInt("bit",24)));
		st.setText(String.valueOf(sp.getInt("fps",30)));
        getWindow().getDecorView().setBackground(d);
        
        
        
        //interaction
        
        new Handler().post(new Runnable(){

                @Override
                public void run() {
                    
                    sh.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {



                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                getSharedPreferences("rec",MODE_PRIVATE).edit().putInt("resh",Integer.parseInt(s.toString())).apply();
                            }
                        });
                        
                    sw.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                getSharedPreferences("rec",MODE_PRIVATE).edit().putInt("resw",Integer.parseInt(s.toString())).apply();
                            }
                        });

                    st.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                getSharedPreferences("rec",MODE_PRIVATE).edit().putInt("fps",Integer.parseInt(s.toString())).apply();
                            }
                        });


                    sb.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                getSharedPreferences("rec",MODE_PRIVATE).edit().putInt("bit",Integer.parseInt(s.toString())).apply();
                            }
                        });
                        
                    
                }
            });
    }
	
} 
