package f00l.r;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Path;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;
import android.os.Handler;
import android.content.SharedPreferences;

public class ass extends AccessibilityService {
	int X,Y;
	@Override
	public void onCreate() {
		super.onCreate();
		SharedPreferences p1=getSharedPreferences("a",MODE_PRIVATE);
		X=p1.getInt("tapX",0);Y=p1.getInt("tapY",0);
		p1.registerOnSharedPreferenceChangeListener(new SharedPreferences.OnSharedPreferenceChangeListener(){

				@Override
				public void onSharedPreferenceChanged(SharedPreferences p1, String p2) {
					X=p1.getInt("tapX",0);Y=p1.getInt("tapY",0);
				}
			});
		
	}
	
	@Override
	public void onAccessibilityEvent(AccessibilityEvent p1) {
	}
	
	@Override
	public void onInterrupt() {
	}

	@Override
	protected boolean onKeyEvent(KeyEvent event) {



        int action = event.getAction(); 

        int keyCode = event.getKeyCode(); 
		
        // the service listens for both pressing and releasing the key 

        // so the below code executes twice, i.e. you would encounter two Toasts 

        // in order to avoid this, we wrap the code inside an if statement 

        // which executes only when the key is released 
		if(a.act){

        if (action == KeyEvent.ACTION_UP) { 

            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) { 
                perform_click();
				return a.act;
            }  

        } else if(action==KeyEvent.ACTION_DOWN){
			
			if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) { 
				dispatchGesture(Click(X,Y,10000),null,null);
				return a.act;
            }}}

		return super.onKeyEvent(event);
	}
	

private void perform_click(){
	dispatchGesture(Click(X,Y,1),null,null);
}
	
	private GestureDescription Click(float x, float y,int dur) {

		Path clickPath = new Path();
		clickPath.moveTo(x, y);
		GestureDescription.StrokeDescription clickStroke =
            new GestureDescription.StrokeDescription(clickPath, 0, dur);
		GestureDescription.Builder clickBuilder = new GestureDescription.Builder();
		clickBuilder.addStroke(clickStroke);
		return clickBuilder.build();
	}
	private boolean isMyServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
}
