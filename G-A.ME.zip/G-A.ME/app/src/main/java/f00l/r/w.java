package f00l.r;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.Toast;
import f00l.r.R;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;;
public class w extends AppWidgetProvider {
    RemoteViews remoteViews;
    private static final String SYNC_CLICKED    = "automaticWidgetSyncButtonClick";
	@Override
	public void onEnabled(Context context) {
		super.onEnabled(context);
	}

	@Override
	public void onReceive(final Context context, Intent intent) {
		super.onReceive(context, intent);
		if (SYNC_CLICKED.equals(intent.getAction()) || Intent.ACTION_SCREEN_ON.equals(intent.getAction())) {

            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);

            ComponentName watchWidget;
            StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long bytesAvailable= stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
            long megAvailable = bytesAvailable / (1024 * 1024);
            long internalTotal = (stat.getBlockCountLong() * stat.getBlockSizeLong()) / (1024 * 1024);
            BatteryManager bm = (BatteryManager) context.getSystemService(context.BATTERY_SERVICE);
            int av=Integer.valueOf(String.valueOf(internalTotal - megAvailable));
            int tol=Integer.valueOf(String.valueOf(internalTotal));			
            int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            remoteViews = new RemoteViews(context.getPackageName(), R.layout.w);
            watchWidget = new ComponentName(context, w.class);
            try {
				if (thems(context)) {remoteViews.setViewVisibility(R.id.wRelativeLayoutBlack, View.VISIBLE);remoteViews.setViewVisibility(R.id.wRelativeLayout1White, View.GONE);
					remoteViews.setTextViewText(R.id.levlblack, batLevel + "%");
					remoteViews.setTextViewText(R.id.repoBlack, note(context));
					remoteViews.setTextViewText(R.id.wTextView1Black, "Free " + megAvailable + "m");
					remoteViews.setProgressBar(R.id.wProgressBatryBlack, 100, batLevel, false);
					remoteViews.setProgressBar(R.id.wProgressBarsBlack, tol, av, false);
					remoteViews.setProgressBar(R.id.wProgressBar1Black, ramf(context), ramf(context) - ramf(context), false);
					remoteViews.setTextViewText(R.id.wTextViewramBlack, rmpu(context));
					remoteViews.setOnClickPendingIntent(R.id.wRelativeLayoutBlack, getPendingSelfIntent(context, SYNC_CLICKED));
					appWidgetManager.updateAppWidget(watchWidget, remoteViews);
				} else {
					remoteViews.setViewVisibility(R.id.wRelativeLayout1, View.VISIBLE);remoteViews.setViewVisibility(R.id.wRelativeLayoutBlack, View.GONE);
					remoteViews.setTextViewText(R.id.levl, batLevel + "%");
					remoteViews.setTextViewText(R.id.repo, note(context));
					remoteViews.setTextViewText(R.id.wTextView1, "Free " + megAvailable + "m");
					remoteViews.setProgressBar(R.id.wProgressBatry, 100, batLevel, false);
					remoteViews.setProgressBar(R.id.wProgressBars, tol, av, false);
					remoteViews.setProgressBar(R.id.wProgressBar1, ramf(context), ramf(context) - ramf(context), false);
					remoteViews.setTextViewText(R.id.wTextViewram, rmpu(context));
					remoteViews.setOnClickPendingIntent(R.id.Touchy, getPendingSelfIntent(context, SYNC_CLICKED));
					appWidgetManager.updateAppWidget(watchWidget, remoteViews);
				}
				new Handler().post(new Runnable(){

						@Override
						public void run() {
							try {int befr=ramf(context);
								v(context);
								Toast.makeText(context, befr-ramf(context)+"mb cleaned", Toast.LENGTH_SHORT).show();
							} catch (Exception e) {}
						}
					});

			} catch (Exception e) {Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();}
        }
	}

	private boolean thems(Context context) {
		switch (context.getSharedPreferences("thems", context.MODE_PRIVATE).getInt("Mode", 0)) {
			case 0:return isbright();
			case 1:return true;
			case 2:return false;
		}return false;
	}

	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		super.onDeleted(context, appWidgetIds);
	}

	@Override
	public void onDisabled(Context context) {
		super.onDisabled(context);
	}
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		ComponentName thisWidget = new ComponentName(context, w.class);
		int[] allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long bytesAvailable= stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
        long megAvailable = bytesAvailable / (1024 * 1024);
        long internalTotal = (stat.getBlockCountLong() * stat.getBlockSizeLong()) / (1024 * 1024);
        BatteryManager bm = (BatteryManager) context.getSystemService(context.BATTERY_SERVICE);
        int av=Integer.valueOf(String.valueOf(internalTotal - megAvailable));
        int tol=Integer.valueOf(String.valueOf(internalTotal));
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("note", true);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
        int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
		for (int widgetId : allWidgetIds) {
			RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.w);
            remoteViews.setViewVisibility(R.id.wTextView, View.GONE);
            remoteViews.setTextViewText(R.id.levl, batLevel + "%");
			if (thems(context)) {
				remoteViews.setViewVisibility(R.id.wRelativeLayoutBlack, View.VISIBLE);remoteViews.setViewVisibility(R.id.wRelativeLayout1White, View.GONE);
				remoteViews.setTextViewText(R.id.levlblack, batLevel + "%");
				try {remoteViews.setTextViewText(R.id.repoBlack, note(context));} catch (Exception e) {}
				remoteViews.setTextViewText(R.id.wTextView1Black, "Free " + megAvailable + "m");
				remoteViews.setProgressBar(R.id.wProgressBatryBlack, 100, batLevel, false);
				remoteViews.setProgressBar(R.id.wProgressBarsBlack, tol, av, false);
				remoteViews.setProgressBar(R.id.wProgressBar1Black, ramf(context), ramf(context) - ramf(context), false);
				remoteViews.setTextViewText(R.id.wTextViewramBlack, rmpu(context));
				remoteViews.setOnClickPendingIntent(R.id.wRelativeLayoutBlack, getPendingSelfIntent(context, SYNC_CLICKED));
				appWidgetManager.updateAppWidget(widgetId, remoteViews);
			} else {
				remoteViews.setViewVisibility(R.id.wRelativeLayout1White, View.VISIBLE);remoteViews.setViewVisibility(R.id.wRelativeLayoutBlack, View.GONE);
				remoteViews.setOnClickPendingIntent(R.id.wRelativeLayout3, pendingIntent);
				remoteViews.setInt(R.id.wImageView1, "setColorFilter", Color.LTGRAY);
				remoteViews.setTextViewText(R.id.wTextView1, "Free " + megAvailable + "m");
				remoteViews.setProgressBar(R.id.wProgressBatry, 100, batLevel, false);
				remoteViews.setProgressBar(R.id.wProgressBars, tol, av, false);
				remoteViews.setProgressBar(R.id.wProgressBar1, ramf(context), ramf(context) - ramf(context), false);
				remoteViews.setViewVisibility(R.id.wRelativeLayout1, View.VISIBLE);
				remoteViews.setTextViewText(R.id.wTextViewram, rmpu(context));
				remoteViews.setOnClickPendingIntent(R.id.Touchy, getPendingSelfIntent(context, SYNC_CLICKED));
				appWidgetManager.updateAppWidget(widgetId, remoteViews);
			}
            try {
                remoteViews.setTextViewText(R.id.repo, note(context));
                remoteViews.setTextViewText(R.id.repoBlack, note(context));
            } catch (Exception e) {}
		}
	}
    void v(Context c)throws Exception {
		List<ApplicationInfo> packages;
		PackageManager pm;
		pm = c.getPackageManager();
		packages = pm.getInstalledApplications(0);

		ActivityManager mActivityManager = (ActivityManager)c.getSystemService(c.ACTIVITY_SERVICE);
		String myPackage =c.getApplicationContext().getPackageName();
		for (ApplicationInfo packageInfo : packages) {
			// Thread.sleep(360);
			if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)continue;
			if (packageInfo.packageName.equals(myPackage)) continue;
			mActivityManager.killBackgroundProcesses(packageInfo.packageName);
			Runtime.getRuntime().exec("am force-stop " + packageInfo.packageName);
			Runtime.getRuntime().exec("am kill " + packageInfo.packageName);
			Runtime.getRuntime().exec("am kill-all ");
		}Toast.makeText(c, " cleaned", Toast.LENGTH_SHORT).show();
	}
	protected PendingIntent getPendingSelfIntent(Context context, String action) {
        Intent intent = new Intent(context, getClass());
        intent.setAction(action);
        return PendingIntent.getBroadcast(context, 0, intent, 0);
    }
	public int ramf(Context c) {
		MemoryInfo mi = new MemoryInfo();
		ActivityManager activityManager = (ActivityManager)c.getSystemService(c.ACTIVITY_SERVICE);
		activityManager.getMemoryInfo(mi);
		int availableMegs = (int)(mi.availMem / 0x100000L);
		//String s=String.valueOf(availableMegs+"m");
		return availableMegs;
	}
    public String rmpu(Context c) {

        return String.valueOf("Ram: " + ramf(c) + "m");
    }
    public String note(Context c) {
        String[] not={"Set a Note...","Lets focus on work","Let me remember for you"};
        int r= new Random().nextInt(not.length);
        try {
            Scanner scanner = new Scanner(new File(Environment.getExternalStorageDirectory()+"/note.txt"));

			StringBuffer stringBuffer = new StringBuffer();
			while (scanner.hasNext()) {
				stringBuffer.append(new StringBuffer().append("\n").append(scanner.nextLine()).toString());
			}
			if (!String.valueOf(stringBuffer).equals(null)) {return String.valueOf(stringBuffer); } else {return not[r];}
        } catch (FileNotFoundException e) {return not[r];}
    }

    private boolean isbright() {
		int color=bacteria.text;
		double a = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255;
		return a <= 0.35 ? true : false;
    }
//	public boolean isbright(
//	){
//		if(bacteria.text==Color.WHITE){return false;}else{return true;}
//	}
}
