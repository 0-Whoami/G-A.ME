package f00l.r;

import android.annotation.NonNull;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;
import f00l.r.Shell;
import f00l.r.appon;
import java.lang.reflect.Field;

public class new_a extends Service implements View.OnClickListener,View.OnLongClickListener {

	private Notification no;
	private View mFloatingView;
	private String s="idch";
	private WindowManager.LayoutParams paeams;
	private WindowManager mWindowManager;
	private View game;
	private View apps;
	private View main;
	private View devlop;
	private String app1name;
	private String app2name;
	private SharedPreferences shp;
	private EditText path;
	private boolean isDevoloper;
	private LinearLayout container;
	View preload;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent == null) {
			return START_NOT_STICKY;
		}
		return START_STICKY;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		startCommand();
		mFloatingView = LayoutInflater.from(new_a.this).inflate(R.layout.newa, null);
		paeams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			pa(),
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
			PixelFormat.TRANSLUCENT);
		paeams.gravity = Gravity.CENTER_VERTICAL | kwin();
		paeams.x = 0;
		paeams.y = 0;		
		mWindowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
		mWindowManager.addView(mFloatingView, paeams);

		CompoundButton dnd=mFloatingView.findViewById(R.id.newdnd);
		ImageButton app1=mFloatingView.findViewById(R.id.app1);
		ImageButton app2=mFloatingView.findViewById(R.id.app2);
		ImageButton gamebutton=mFloatingView.findViewById(R.id.gamebutton);
		ImageButton appsbutton=mFloatingView.findViewById(R.id.appsbutton);
		SeekBar brightness=mFloatingView.findViewById(R.id.brightness_slider);
		shp = getSharedPreferences("a", MODE_PRIVATE);
		isDevoloper = shp.getBoolean("dev", false);
		app1name = shp.getString("2", null);
		path = mFloatingView.findViewById(R.id.newaEditText);
		app2name = shp.getString("app2", null);
		devlop = mFloatingView.findViewById(R.id.devlopm);
		main = mFloatingView.findViewById(R.id.main);
		game = mFloatingView.findViewById(R.id.game);
		apps = mFloatingView.findViewById(R.id.apps);
		Drawable app1drawble=appicon(app1name);
		Drawable app2drawabl=appicon(app2name);
		container = mFloatingView.findViewById(R.id.shortcut_container);
		ProgressBar battrylvl=mFloatingView.findViewById(R.id.Battrylavel);
		BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);
		int battrylevel=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);



		brightness.setMax(getMaxBrightness(this, 255));
		if (app1drawble != null) {app1.setImageBitmap(resized(app1drawble, 50));}
		if (app2drawabl != null) {app2.setImageBitmap(resized(app2drawabl, 50));}
		battrylvl.setProgress(battrylevel);
		dnd.setChecked(pee.dnd(true, false, this));

		mFloatingView.findViewById(R.id.Animation_Layout).animate().x(40).setDuration(500);
		gamebutton.setOnClickListener(this);
		gamebutton.setOnLongClickListener(this);
		mFloatingView.findViewById(R.id.back5).setOnClickListener(this);
		mFloatingView.findViewById(R.id.aply).setOnClickListener(this);
		appsbutton.setOnClickListener(this);
		app1.setOnClickListener(this);
		app2.setOnClickListener(this);
		mFloatingView.findViewById(R.id.browser).setOnClickListener(this);
		mFloatingView.findViewById(R.id.back0).setOnClickListener(this);
		mFloatingView.findViewById(R.id.back).setOnClickListener(this);
		mFloatingView.findViewById(R.id.exit).setOnClickListener(this);
		mFloatingView.findViewById(R.id.exit).setOnLongClickListener(this);
		mFloatingView.findViewById(R.id.monitor).setOnClickListener(this);
		mFloatingView.findViewById(R.id.boostram).setOnClickListener(this);
		mFloatingView.findViewById(R.id.recordscreen).setOnClickListener(this);
		mFloatingView.findViewById(R.id.presets).setOnClickListener(this);
		mFloatingView.findViewById(R.id.mannualctrl).setOnClickListener(this);
		mFloatingView.findViewById(R.id.vcyest).setOnClickListener(this);
		try {
			brightness.setProgress(android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS), true);
			brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

					@Override
					public void onProgressChanged(SeekBar p1, int p2, boolean p3) {
						mFloatingView.findViewById(R.id.rotationfx).setRotation(p2 * 2);
						Applications.createShells.ScreenBrightness(p2, new_a.this);
					}

					@Override
					public void onStartTrackingTouch(SeekBar p1) {
					}

					@Override
					public void onStopTrackingTouch(SeekBar p1) {
					}
				});

			dnd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

					@Override
					public void onCheckedChanged(CompoundButton p1, boolean p2) {
						pee.dnd(p2, true, new_a.this);
					}
				});
		} catch (Exception e) {}
		preload = a.container;
		container.addView(preload);

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		container.removeAllViews();
		mWindowManager.removeView(mFloatingView);         
		relese();
	}

	@Override
	public boolean onLongClick(View p1) {
		switch (p1.getId()) {
			case R.id.exit:if (isDevoloper) {pee.eyepro(this);}break;
			case R.id.gamebutton:if (isDevoloper) {keyi();devlop.setVisibility(View.VISIBLE);main.setVisibility(View.GONE);}break;
		}
		return false;
	}

	@Override
	public void onClick(View p1) {
		switch (p1.getId()) {
			case R.id.vcyest:startForegroundService(new Intent(this,vdo.class).putExtra("vc",true));break;
			case R.id.aply:back(false);loadClass();break;
			case R.id.back5:back(false);keyd();break;
			case R.id.app1:pee.laf(app1name, this);break;
			case R.id.app2:pee.laf(app2name, this);break;
			case R.id.recordscreen:startActivity(new Intent(this, Screenrecorder.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));stopSelf();break;
			case R.id.boostram:Applications.createShells.ka(this);break;
			case R.id.presets:perfm();break;
			case R.id.mannualctrl:startService(new Intent(this, c.class));break;
			case R.id.monitor:if (!isMyServiceRunning(mi.class)) {startService(new Intent(this, mi.class));} else {stopService(new Intent(this, mi.class));}break;
			case R.id.browser:startService(new Intent(this, b.class));break;
			case R.id.exit:back(true);break;
			case R.id.back:back(false);break;
			case R.id.back0:back(false);break;
			case R.id.gamebutton:game.setVisibility(View.VISIBLE);main.setVisibility(View.GONE);break;
			case R.id.appsbutton:apps.setVisibility(View.VISIBLE);main.setVisibility(View.GONE);break;
		}
	}


    private void startCommand() {no = new Notification.Builder(this, this.s).setSmallIcon(R.drawable.butterfly).setChannelId(s).setShowWhen(false).build();
		startForeground(1, no);
	}
	int pa() {
		if (Build.VERSION.SDK_INT >= 27) {
			return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
		} else {return WindowManager.LayoutParams.TYPE_PHONE;}
	}
	private void relese() {
		paeams = null;
		mWindowManager = null;
		stopSelf();
	}

	private int kwin() {
		if (getSharedPreferences("a", MODE_PRIVATE).getBoolean("4", false)) {return Gravity.RIGHT;} else {return Gravity.LEFT;}
	}
	private void perfm() {
		AlertDialog dialog = new AlertDialog.Builder(this)
			.create();
		dialog.setButton3("     🎮       ", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2) {
					try {
						Shell.sudo("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
					} catch (Shell.ShellException e) {}

					Applications.createShells.perfom(new_a.this);

					Toast t=Toast.makeText(new_a.this, "PERFMAXX MODE STARTED", Toast.LENGTH_SHORT);
					t.setGravity(Gravity.TOP, 0, 0);
					t.getView().setBackgroundColor(Color.RED);
					t.show();
				}
			});
		dialog.setButton2("      🎐      ", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2) {Toast t=Toast.makeText(new_a.this, "Normalizing..", Toast.LENGTH_SHORT);
					t.setGravity(Gravity.TOP, 0, 0);
					try {
						appon.aiload(new_a.this); } catch (Exception e) {}
					t.getView().setBackgroundColor(Color.YELLOW);t.show();
				}
			});
		dialog.setButton("                🔋      ", new DialogInterface.OnClickListener(){

				@Override
				public void onClick(DialogInterface p1, int p2) {Toast t=Toast.makeText(new_a.this, "Ultra battry saver", Toast.LENGTH_SHORT);
					t.setGravity(Gravity.TOP, 0, 0);
					try {
						Shell.sudo("echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
					} catch (Shell.ShellException e) {}
					try {
						Applications.createShells.battry(new_a.this);
					} catch (Exception e) {}
					t.getView().setBackgroundColor(Color.GREEN);t.show();
				}
			});
		dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
		dialog.show();
	}
	private boolean isMyServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	private void back(boolean exit) {
		if (exit) {stopSelf();stopForeground(true);} else {
			devlop.setVisibility(View.GONE);game.setVisibility(View.GONE);apps.setVisibility(View.GONE);main.setVisibility(View.VISIBLE);
		}
	}
	@NonNull
	private Bitmap resized(@NonNull Drawable drawable, int height) {
		final Bitmap bmp = Bitmap.createBitmap(height, height, Bitmap.Config.ARGB_8888);
		final Canvas canvas = new Canvas(bmp);
		drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		drawable.draw(canvas);
		return bmp;
	}
	private void keyi() {paeams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;mWindowManager.updateViewLayout(mFloatingView, paeams);}
	private void keyd() {paeams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;mWindowManager.updateViewLayout(mFloatingView, paeams);}
	Drawable appicon(String s) {
		try {
			Drawable appic= getPackageManager().getApplicationIcon(s);
			return appic;
		} catch (Exception e) {}
		return null;
	}
	public int getMaxBrightness(Context context, int defaultValue) {

		PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
		if (powerManager != null) {
			Field[] fields = powerManager.getClass().getDeclaredFields();
			for (Field field: fields) {
				if (field.getName().equals("BRIGHTNESS_ON")) {
					field.setAccessible(true);
					try {
						return (int) field.get(powerManager);
					} catch (IllegalAccessException e) {
						return defaultValue;
					}
				}
			}
		}
		return defaultValue;
	}
	private void loadClass() {
		String[] pathd=path.getText().toString().split(",");
		try {
			cr.deg(pathd[0], pathd[1], this);
		} catch (Exception e) {}
	}
}
