package f00l.r;
 
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.icu.math.BigDecimal;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import f00l.r.Applications;
import f00l.r.R;
import f00l.r.Shell;
import f00l.r.Tws;
import f00l.r.bacteria;
import java.io.IOException;

public class misc extends Activity { 
     String[] zrams={"0M","265M","512M","1024M","2048M","3072M","4096M"};
	 ToggleButton cbs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		if(bacteria.text==Color.BLACK){setTheme(R.style.AppThemeWhite);}else{setTheme(R.style.AppTheme);}
        setContentView(R.layout.misc);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
      
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    protected void onResume() {
        super.onResume();
        final EditText heght=findViewById(R.id.xlEditText6);
        final EditText widt=findViewById(R.id.xlwidth);
		final EditText dpi=findViewById(R.id.xldpi);
        final CheckBox cechb=findViewById(R.id.xlCheckBox1);
        final Button restgraph= findViewById(R.id.resr);
        final Button setgrap=findViewById(R.id.xlButton4);
        final ToggleButton tog =findViewById(R.id.xlToggleButton1);
	    cbs=findViewById(R.id.xlcb);
        final ToggleButton s2=findViewById(R.id.xlgrapic);
        final Button clr=findViewById(R.id.xlButton5);
        final RadioGroup dv=findViewById(R.id.xldozeview);
        final RadioButton nd =findViewById(R.id.xnd);
        final RadioButton ld =findViewById(R.id.xld);
        final RadioButton dd=findViewById(R.id.xdd);
        final RadioButton widgettemeauto=findViewById(R.id.autowidget);
		final RadioButton widgetblack=findViewById(R.id.blackwidget);
		final RadioButton widgetwhite=findViewById(R.id.whitewidget);
		final Spinner spinner=findViewById(R.id.miscSpinner);
        ArrayAdapter ad  = new ArrayAdapter(this,android.R.layout.simple_spinner_item,zrams); 
		
		
		spinner.setAdapter(ad);
        final Bitmap b=((BitmapDrawable)getWallpaper()).getBitmap();
        final Bitmap bb=bacteria.blur(this,b);
        Drawable d=new BitmapDrawable(getResources(),bb);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();display.getRealSize(size);
        final double width = size.x;
        final double height =size.y;
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        final int dDpi = (int)(metrics.density * 160f);
        final double k1=height/width;
        final Double k2=dDpi/height;
        final double k3 =dDpi/width;
        Drawable pubg=getResources().getDrawable(R.drawable.pubg_alt3,getTheme());
        Drawable thems=getResources().getDrawable(R.drawable.themes_alt,getTheme());
        Drawable cpuz=getResources().getDrawable(R.drawable.cpu_z);
        pubg.setBounds(0,0,tog.getLineHeight()*3,tog.getLineHeight()*3);
        thems.setBounds(0,0,tog.getLineHeight()*3,tog.getLineHeight()*3);
        cpuz.setBounds(0,0,tog.getLineHeight()*3,tog.getLineHeight()*3);
        final SharedPreferences shp=getSharedPreferences("doze",MODE_PRIVATE);
        ImageSpan ims1=new ImageSpan(pubg);
        ImageSpan ims2=new ImageSpan(thems);
        ImageSpan ims3=new ImageSpan(cpuz);
		final SharedPreferences widget=getSharedPreferences("thems",MODE_PRIVATE);
        SpannableStringBuilder sp=new SpannableStringBuilder("FPS Unlocker ");
        SpannableStringBuilder sp2=new SpannableStringBuilder("Color boost ");
        SpannableStringBuilder spe=new SpannableStringBuilder("Andvance LKM ");
        int text=bacteria.getContrastColor(bacteria.getDominantColor(b));
        
        
         getWindow().getDecorView().setBackground(d);
        if(k1()==0){getSharedPreferences("d",MODE_PRIVATE).edit().putLong("k1",Double.doubleToLongBits(k1)).apply();}
        if(k2()==0){getSharedPreferences("d",MODE_PRIVATE).edit().putLong("k2",Double.doubleToLongBits(k2)).apply();}
        if(k3()==0){getSharedPreferences("d",MODE_PRIVATE).edit().putLong("k3",Double.doubleToLongBits(k3)).apply();}
		tog.setChecked(getSharedPreferences("a",MODE_PRIVATE).getBoolean("lkm",false));
        cbs.setChecked(getSharedPreferences("a",MODE_PRIVATE).getBoolean("3",false));
        s2.setChecked(getSharedPreferences("pee",MODE_PRIVATE).getBoolean("gameun",false));
        dv.setClipToOutline(true);
        if(shp.getBoolean("nd",true)){nd.setChecked(true);nd.setBackgroundResource(R.drawable.Tile_sec);
		nd.setBackgroundColor(Color.LTGRAY);
            dv.getBackground().setColorFilter(Color.LTGRAY,PorterDuff.Mode.SRC_IN);}
        if(shp.getBoolean("ld",false)){ld.setChecked(true);ld.setBackgroundResource(R.drawable.Tile_sec);
		ld.setBackgroundColor(Color.GRAY);dv.getBackground().setColorFilter(Color.GRAY,PorterDuff.Mode.SRC_IN);}
        if(shp.getBoolean("dd",false)){dd.setChecked(true);dd.setBackgroundResource(R.drawable.Tile_sec);
		nd.setBackgroundColor(Color.DKGRAY);dv.getBackground().setColorFilter(Color.DKGRAY,PorterDuff.Mode.SRC_IN);}
        heght.setText(String.valueOf(height));
        widt.setText(String.valueOf(width));
		dpi.setText(String.valueOf(dDpi));	
        sp.setSpan(ims1,sp.length()-1,sp.length(),Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        sp2.setSpan(ims2,sp2.length()-1,sp2.length(),Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        spe.setSpan(ims3,spe.length()-1,spe.length(),Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        tog.setTextOn(spe);
        cbs.setTextOn(sp2);
        s2.setTextOn(sp);
        tog.setTextOff(spe);
        cbs.setTextOff(sp2);
        s2.setTextOff(sp);
        tog.setText(spe,TextView.BufferType.SPANNABLE);
        cbs.setText(sp2,TextView.BufferType.SPANNABLE);
        s2.setText(sp,TextView.BufferType.SPANNABLE);
        widgettemeauto.setChecked(widget.getBoolean("auto",true));
		widgetblack.setChecked(widget.getBoolean("black",false));
		widgetwhite.setChecked(widget.getBoolean("white",false));
        
        s2.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
        cbs.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
        tog.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
        s2.setTextColor(text);
        cbs.setTextColor(text);
        tog.setTextColor(text);
        cechb.setTextColor(text);
        dpi.setTextColor(text);
        setgrap.setTextColor(text);
        restgraph.setTextColor(text);
        clr.setTextColor(text);
        heght.setTextColor(text);
        widt.setTextColor(text);
		widgettemeauto.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
        widgetblack.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
        widgetwhite.getBackground().setColorFilter(text,PorterDuff.Mode.MULTIPLY);
		widgettemeauto.setTextColor(text);
        widgetblack.setTextColor(text);
        widgetwhite.setTextColor(text);
        ld.setTextColor(text);
		nd.setTextColor(text);
		dd.setTextColor(text);
		
        // interaction
        
        new Handler().post(new Runnable(){

                @Override
                public void run() {
					findViewById(R.id.zrambutton).setOnClickListener(new View.OnClickListener() {

							@Override
							public void onClick(View view) {
							Applications.createShells.Zram(zrams[spinner.getSelectedItemPosition()]);
							}
                        });
					widgettemeauto.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

							@Override
							public void onCheckedChanged(CompoundButton p1, boolean p2) {
								widget.edit().putBoolean("auto",p2).apply();
								if(p2){widget.edit().putInt("Mode",0).apply();}
							}
						});
					widgetblack.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

							@Override
							public void onCheckedChanged(CompoundButton p1, boolean p2) {
								widget.edit().putBoolean("black",p2).apply();
								if(p2){widget.edit().putInt("Mode",1).apply();}}
						});
					widgetwhite.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

							@Override
							public void onCheckedChanged(CompoundButton p1, boolean p2) {
								widget.edit().putBoolean("white",p2).apply();
								if(p2){widget.edit().putInt("Mode",2).apply();}}
						});
                    nd.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                if (p2) {try {
                                        Shell.sudo("dumpsys deviceidle force-inactive");
                                    } catch (Shell.ShellException e) {}
                                    p1.setBackgroundResource(R.drawable.Tile_sec);
                                    dv.getBackground().setColorFilter(Color.LTGRAY,PorterDuff.Mode.SRC_IN);}else{p1.setBackgroundColor(Color.TRANSPARENT);}shp.edit().putBoolean("nd",p2).apply();
                            }
                        });
                    
                    
                    ld.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                {shp.edit().putBoolean("ld",p2).apply();
                                    if (p2) {try {
                                            Shell.sudo("dumpsys deviceidle force-idle light");
                                        } catch (Shell.ShellException e) {}
                                        p1.setBackgroundResource(R.drawable.Tile_sec);
                                        dv.getBackground().setColorFilter(Color.GRAY,PorterDuff.Mode.SRC_IN);}else{p1.setBackgroundColor(Color.TRANSPARENT);}
                                }}
                        });
                    
                    
                    dd.setOnCheckedChangeListener(new RadioButton.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                {shp.edit().putBoolean("dd",p2).apply();
                                    if (p2) {try {
                                            Shell.sudo("dumpsys deviceidle force-idle deep");
                                        } catch (Shell.ShellException e) {}
                                        p1.setBackgroundResource(R.drawable.Tile_sec);
                                        dv.getBackground().setColorFilter(Color.DKGRAY,PorterDuff.Mode.SRC_IN);}else{p1.setBackgroundColor(Color.TRANSPARENT);}
                                }}
                        });
                    
                    clr.setOnClickListener(new View.OnClickListener(){

                            @Override
                            public void onClick(View p1) {Applications.createShells.fstrim(misc.this);
                            }
                        });
                    
                    findViewById(R.id.xlButton1).setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                               
                                    AlertDialog dialog = new AlertDialog.Builder(misc.this, android.R.style.Theme_Material_Dialog_Alert)
                                        .setTitle("Notice :")
                                        .setMessage("This feature has been removed from the app for security reason . Join our telegram group to use this feature")
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dia, int which) {
                                                try {
                                                    Applications.createShells.telg(misc.this);
                                                } catch (Exception e) {Toast.makeText(getApplication(),""+ e, Toast.LENGTH_SHORT).show();}
                                            }
                                        })
                                        .setNegativeButton("Cancel", null)
                                        .create();
                                    dialog.show();

                            }
                        });
                    
                    tog.setOnCheckedChangeListener(new ToggleButton.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                if(p2){Applications.createShells.activateLMK(misc.this);}else{Applications.createShells.restoreOriginalLMK(misc.this);}
                            }
                        });
                    
                    heght.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                if(!heght.getText().toString().isEmpty()&&heght.hasFocus()&&cechb.isChecked()){widt.setText(String.valueOf(Double.parseDouble(s.toString())*(1/k1())));dpi.setText(String.valueOf(  dDpi*(Double.parseDouble(s.toString())/height)  ));}
                            }
                        });

                    widt.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                if(!widt.getText().toString().isEmpty()&&widt.hasFocus()&&cechb.isChecked()){heght.setText(String.valueOf(Double.parseDouble(s.toString())*(k1())));dpi.setText(String.valueOf(  dDpi*(Double.parseDouble(s.toString())/width)  ));}
                            }
                        });

                    dpi.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start,int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                if(!dpi.getText().toString().isEmpty()&&dpi.hasFocus()&&cechb.isChecked()){widt.setText(String.valueOf(Double.parseDouble(s.toString())*(k3())));heght.setText(String.valueOf(  (Double.parseDouble(s.toString())*k2())  ));}
                            }
                        });
                        
                    setgrap.setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                try {
                                    BigDecimal hi=new BigDecimal(heght.getText().toString());
                                    BigDecimal hii=hi.setScale(0,BigDecimal.ROUND_HALF_UP);
                                    BigDecimal wi=new BigDecimal(widt.getText().toString());
                                    BigDecimal wii=wi.setScale(0,BigDecimal.ROUND_HALF_UP);
                                    BigDecimal di=new BigDecimal(dpi.getText().toString());
                                    BigDecimal dii=di.setScale(0,BigDecimal.ROUND_HALF_UP);

                                    Shell.sudo(" wm size "+wii+"x"+hii);
                                    Shell.sudo(" wm density "+dii);
                                    Toast.makeText(getApplication(), wii+"x"+hii+" "+dii, Toast.LENGTH_SHORT).show();
                                } catch (Exception e) {}
                            }
                        });

                    restgraph.setOnClickListener(new View.OnClickListener(){

                            @Override
                            public void onClick(View p1) {try {
                                    Shell.sudo(" wm size reset");Shell.sudo(" wm density reset");
                                } catch (Exception e) {}
                            }
                        });
                        
                    s2.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                getSharedPreferences("pee",MODE_PRIVATE).edit().putBoolean("gameun",p2);
                                if(p2){Tws.backupBuildProp(misc.this);Applications.createShells.gameunlocker();}else{Tws.restoreBuildProp(misc.this);}
                            }
                        });
					cbs.setOnLongClickListener(new View.OnLongClickListener() {

							@Override
							public boolean onLongClick(View view) {
								customColorBoost();
								return false;
							}
                        });
                        
                        cbs.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                Applications.createShells.c(p2,misc.this);}
                        });
                }
            });
    }
    
    double k1(){
        return Double.longBitsToDouble(getSharedPreferences("d",MODE_PRIVATE).getLong("k1",0));
    }
    double k2(){
        return Double.longBitsToDouble(getSharedPreferences("d",MODE_PRIVATE).getLong("k2",0));
    }
    double k3(){
        return Double.longBitsToDouble(getSharedPreferences("d",MODE_PRIVATE).getLong("k3",0));
	}
	
	void customColorBoost(){
		AlertDialog dialog = new AlertDialog.Builder(this).create();
		SeekBar s= new SeekBar(this);
		s.setMax(20);
		s.setProgress(10);
			dialog.setView(s);
		s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

				@Override
				public void onProgressChanged(SeekBar p1, int p2, boolean p3) {
					try {
						Applications.createShells.dtaoutput.writeBytes(" service call SurfaceFlinger 1022 f "+p1.getProgress()/10f+"\n");
						Applications.createShells.dtaoutput.flush();
					} catch (IOException e) {}
					getSharedPreferences("a", c.MODE_PRIVATE).edit().putBoolean("3", true).apply();
					cbs.setChecked(true);
					
				}

				@Override
				public void onStartTrackingTouch(SeekBar p1) {
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar p1) {
					
				}
			});
		dialog.show();
	}
} 
