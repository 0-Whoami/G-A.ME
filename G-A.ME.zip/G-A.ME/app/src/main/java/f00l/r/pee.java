package f00l.r;

import android.app.ActivityManager;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class pee {
	public static DataOutputStream dtaoutput;
	public static DataOutputStream nonsu;
	public pee() {
		try {
			Process p=Runtime.getRuntime().exec("su");
			dtaoutput = new DataOutputStream(p.getOutputStream());
			Process p2=Runtime.getRuntime().exec("\n");
			nonsu = new DataOutputStream(p2.getOutputStream());
		} catch (Exception e) {try {
				Process p=Runtime.getRuntime().exec("cd /storage/emulated/0/G-A.ME/ && sh rish");
				dtaoutput = new DataOutputStream(p.getOutputStream());
			} catch (IOException eo) {}}
	}
    public static boolean ishmp()throws Exception {
        String s= Shell.sudo(" cat /sys/devices/system/cpu/cpu0/scaling_available_governors");
        if (s.contains("interactive")) {return true;} else {return false;}
    }
	public static void pb(String pkg) {
		try {
			dtaoutput.writeBytes("renice -n -20 $(pgrep " + pkg + ")\n");
			dtaoutput.flush();
			dtaoutput.writeBytes("echo $(pgrep " + pkg + ") >/dev/cpuset/foreground/boost/tasks\n");
			dtaoutput.flush();
		} catch (Exception e) {}
	}
    public static void fstrim(final Context c) {
		Thread thd= new Thread(){   @Override
			public void run() {
				Looper.prepare();
				{BufferedReader reader = null;
					try {
						reader = new BufferedReader(
							new InputStreamReader(c.getAssets().open("trash.txt"), "UTF-8")); 

						String mLine;
						while ((mLine = reader.readLine()) != null) {try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {}

							try {
								dtaoutput.writeBytes(mLine + "\n");
								dtaoutput.flush();
							} catch (Exception e) {}
						}
					} catch (IOException e) {
					} finally {
						if (reader != null) {
							try {
								reader.close();
								Toast.makeText(c, "Done", Toast.LENGTH_SHORT).show();

							} catch (IOException e) {
							}
						}
					} }}};thd.start();

    }
	public static void OnSuShell(String s) {try {
			dtaoutput.writeBytes(s);
		} catch (IOException e) {}}
	public static void gen(final Context c) {
		Thread thd= new Thread(){   @Override
			public void run() {try {
					Thread.sleep(1000);
					String path=Environment.getExternalStorageDirectory() + "/G-A.ME/Opt.sh";
					Shell.sudo("chmod 777 " + path);
					Shell.sudo("bash " + path);
				} catch (Exception e) {}
				{BufferedReader reader = null;
					try {
						reader = new BufferedReader(
							new InputStreamReader(c.getAssets().open("Gen.txt"), "UTF-8")); 
						String mLine;
						while ((mLine = reader.readLine()) != null) {try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {}

							try {
								dtaoutput.writeBytes(mLine + "\n");
								dtaoutput.flush();
							} catch (Exception e) {}
						}
					} catch (IOException e) {
					} finally {
						if (reader != null) {
							try {
								reader.close();
							} catch (IOException e) {
							}
						}
					} }}};thd.start();
    }
    public static void perfom(final Context c) {
		Thread thd= new Thread(){   @Override
			public void run() {try {
					Thread.sleep(1000);
					String path=Environment.getExternalStorageDirectory() + "/G-A.ME/perf.sh";
					Shell.sudo("chmod 777 " + path);
					Shell.sudo("bash " + path);
				} catch (Exception e) {}
				{BufferedReader reader = null;
					try {
						reader = new BufferedReader(
							new InputStreamReader(c.getAssets().open("pee.txt"), "UTF-8")); 

						String mLine;
						while ((mLine = reader.readLine()) != null) {try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {}

							try {
								dtaoutput.writeBytes(mLine + "\n");
								dtaoutput.flush();
							} catch (Exception e) {}
						}
					} catch (IOException e) {
					} finally {
						if (reader != null) {
							try {
								reader.close();
							} catch (IOException e) {
							}
						}
					} }}};thd.start();
    }
    public static void battry(final Context c)throws Exception {
		Thread thd= new Thread(){   @Override
			public void run() {try {
					Thread.sleep(1000);
					String path=Environment.getExternalStorageDirectory() + "/G-A.ME/batt.sh";
					Shell.sudo("chmod 777 " + path);
					Shell.sudo("bash " + path);
				} catch (Exception e) {}
				{BufferedReader reader = null;
					try {
						reader = new BufferedReader(
							new InputStreamReader(c.getAssets().open("but.txt"), "UTF-8")); 

						String mLine;
						while ((mLine = reader.readLine()) != null) {try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {}

							try {
								dtaoutput.writeBytes(mLine + "\n");
								dtaoutput.flush();
							} catch (Exception e) {}
						}
					} catch (IOException e) {
					} finally {
						if (reader != null) {
							try {
								reader.close();
							} catch (IOException e) {
							}
						}
					} }}};thd.start();
    }
	public static void  balance(final Context c, boolean b)throws Exception {
		Thread thd= new Thread(){   @Override
			public void run() {try {
					Thread.sleep(1000);
					String path=Environment.getExternalStorageDirectory() + "/G-A.ME/bal.sh";
					Shell.sudo("chmod 777 " + path);
					Shell.sudo("bash " + path);
				} catch (Exception e) {}
				{ BufferedReader reader = null;
					try {
						reader = new BufferedReader(
							new InputStreamReader(c.getAssets().open("bal.txt"), "UTF-8")); 

						String mLine;
						while ((mLine = reader.readLine()) != null) {try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {}

							try {
								dtaoutput.writeBytes("echo " + mLine + " >> /system/build.prop" + " \n");
								dtaoutput.flush();
							} catch (Exception e) {}
						}
					} catch (IOException e) {
					} finally {
						if (reader != null) {
							try {
								reader.close();
							} catch (IOException e) {
							}
						}
					}}}};thd.start();}
	public static String gpudri(Context c) throws Exception {
		SharedPreferences s=c.getSharedPreferences("gpudir", c.MODE_PRIVATE);
		SharedPreferences.Editor se=s.edit();
		if (s.getString("gpudir", null).isEmpty()) {String sr=  Shell.sudo("find / -name \"available_governors\" 2> /dev/null").replaceAll("available_governors", "");
			se.putString("gpudir", sr).apply();}
		return s.getString("gpudir", null);
	}
	public static void setcpufreq(String freq, int culster)throws Exception {
		String[] clus=Shell.sudo("ls -d /sys/devices/system/cpu/cpufreq/policy*").split(System.lineSeparator());
		Shell.sudo("echo " + freq + " > " + clus[culster] + "/scaling_setspeed");
	}
	public static void setgpufreq(int freq, boolean boost, Context c)throws Exception {
		Shell.sudo("chmod 777 " + gpudri(c) + "governor");
		Shell.sudo("echo userspace >" + gpudri(c) + "governor");
		Shell.sudo("echo " + freq + " > userspace/set_freq");
		String kgsl="/sys/class/kgsl/kgsl-3d0";
		if (boost) {Shell.sudo("echo 3 >" + kgsl + "/devfreq/adrenoboost");
			Shell.sudo("echo 1 >" + kgsl + "/force_no_nap");
			Shell.sudo("echo 0 >" + kgsl + "bus_split");
			Shell.sudo("echo 0 >" + kgsl + "throttling");
			Shell.sudo("echo 1 >" + kgsl + "force_rail_on");
			Shell.sudo("echo 1 >" + kgsl + "force_clk_on");}
		if (!Shell.sudo(gpudri(c) + "available_governors").contains("userspace")) {
			Shell.sudo("echo " + lagency(boost) + " > /d/ged/hal/custom_upbound_gpu_freq");
			if (boost) {Shell.sudo("echo 1 > /d/ged/hal/custom_boost_gpu_freq");}
		}
	}
	public static int lagency(boolean boost)throws Exception {
		if (boost) {return 0;} else {String s=Shell.sudo("cat /d/ged/hal/total_gpu_freq_level_count");
			float i= Float.parseFloat(s);
			return (int)i - 1;}
	}
	public static void gameunlocker() {
		try {dtaoutput.writeBytes(buld("ro.product.model", "ro.product.model=GM1917") + "\n");
			dtaoutput.flush();
			dtaoutput.writeBytes(buld("ro.product.odm.model", "ro.product.odm.model=GM1917") + "\n");
			dtaoutput.flush();
			dtaoutput.writeBytes(buld("ro.product.system_ext.model", " ro.product.system_ext.model=GM1917") + "\n");
			dtaoutput.flush();
			dtaoutput.writeBytes(buld("ro.product.vendor.model", " ro.product.vendor.model=GM1917") + "\n");
			dtaoutput.flush();
			dtaoutput.writeBytes(buld("ro.product.system.model", "ro.product.system.model=GM1917") + "\n");
			dtaoutput.flush();} catch (Exception e) {}
	}
	public static String buld(String old, String ne) {
		return "sed -i '/" + old + "/c\\" + ne + "' /system/build.prop";
	}
	public static void activateLMK(Context context) {context.getSharedPreferences("a", context.MODE_PRIVATE).edit().putBoolean("lkm", true).apply();
		try {
			dtaoutput.writeBytes(" cat /sys/module/lowmemorykiller/parameters/minfree > " + context.getApplicationInfo().dataDir + "/lastLMKProfile.backup\n");
			dtaoutput.flush();
			dtaoutput.writeBytes("  echo 2560,5120,11520,25600,35840,358400 > /sys/module/lowmemorykiller/parameters/minfree\n");
			dtaoutput.flush();
		} catch (Exception e) {Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();}
	}

	public static void restoreOriginalLMK(Context context) {context.getSharedPreferences("a", context.MODE_PRIVATE).edit().putBoolean("lkm", false).apply();
		try {
			dtaoutput.writeBytes(" cat " + context.getApplicationInfo().dataDir + "/lastLMKProfile.backup > /sys/module/lowmemorykiller/parameters/minfree\n");
			dtaoutput.flush();
		} catch (Exception e) {Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();}
		new File(context.getApplicationInfo().dataDir + "/lastLMKProfile.backup").delete();
	}
	public static void eyepro(Context c) {
		AlertDialog dialog = new AlertDialog.Builder(c, android.R.style.Theme_Light)
			.setTitle("Eye Protection")
			.setMessage("This feature will lower ther brightness of screen to reduce eye strain \n WARNING: It tstested on IPS displays only")
			.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dia, int which) {
					try {
						Shell.sudo("echo 1 > /sys/class/leds/lcd-backlight/brightness");
					} catch (Shell.ShellException e) {}
				}
			})
			.setNegativeButton("No", null)
			.create();
		dialog.getWindow().addFlags(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);

	}
	public static void omlet(Context c, View l) {
		Toast t=Toast.makeText(c, "", Toast.LENGTH_LONG);
		t.setView(l);
		t.setGravity(Gravity.TOP | Gravity.LEFT, 10, 10);
		t.show();
	}
	public static boolean isNetworkAvailable(Context c) {
		ConnectivityManager connectivityManager 
			= (ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isAvailable();
	}
	public static void c(boolean b, Context c) {c.getSharedPreferences("a", c.MODE_PRIVATE).edit().putBoolean("3", b).apply();
		if (b) {try {
				dtaoutput.writeBytes(" service call SurfaceFlinger 1022 f 1.5\n");dtaoutput.flush();
			} catch (Exception e) {}} else {try {
				dtaoutput.writeBytes(" service call SurfaceFlinger 1022 f 1.0\n");dtaoutput.flush();
			} catch (Exception e) {}}
	}
	public static boolean dnd(boolean b,boolean apply, Context c) {
		NotificationManager mNotificationManager = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
		if(apply){if (b) {mNotificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);} else {mNotificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);}
	}
	if(mNotificationManager.getCurrentInterruptionFilter()==NotificationManager.INTERRUPTION_FILTER_ALL){
		return false;
	}else{return true;}
		}
	public static void laf(String s, Context c) {
		try {ActivityOptions mOptions = ActivityOptions.makeBasic();
			Intent i = c.getPackageManager().getLaunchIntentForPackage(s)
				.addCategory(Intent.CATEGORY_LAUNCHER)
				.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT |
						  Intent.FLAG_ACTIVITY_NEW_TASK |
						  Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
			try {Class<?> cls = Class.forName("android.app.ActivityOptions");
				cls.getMethod("setLaunchWindowingMode", new Class[]{Integer.TYPE}).invoke(mOptions, new Object[]{new Integer(5)});} catch (Exception e) {}
			Rect mBounds = new Rect(300, 0, 500, 650);
			mOptions = mOptions.setLaunchBounds(mBounds);
			c.startActivity(i, mOptions.toBundle());
		} catch (Exception e) {Toast.makeText(c, "" + e, Toast.LENGTH_LONG).show();}
	}
	public static boolean ScreenBrightness(int level, Context context) {

		try {
			android.provider.Settings.System.putInt(
				context.getContentResolver(),
				android.provider.Settings.System.SCREEN_BRIGHTNESS, level);


			android.provider.Settings.System.putInt(context.getContentResolver(),
													android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, 
													android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);

			android.provider.Settings.System.putInt(
				context.getContentResolver(),
				android.provider.Settings.System.SCREEN_BRIGHTNESS, 
				level);


			return true;
		} catch (Exception e) {
			return false;
		}
	}
	public static void ka(final Context c) {
		try {
			Thread thd= new Thread(){
				@Override
				public void run() {
					List<ApplicationInfo> packages;
					PackageManager pm;
					pm = c.getPackageManager();
					packages = pm.getInstalledApplications(0);

					ActivityManager mActivityManager = (ActivityManager)c.getSystemService(c.ACTIVITY_SERVICE);
					String myPackage =c.getApplicationContext().getPackageName();
					for (ApplicationInfo packageInfo : packages) {
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {}
						if ((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 1)continue;
						if (packageInfo.packageName.equals(myPackage)) continue;
						mActivityManager.killBackgroundProcesses(packageInfo.packageName);
						try {nonsu.writeBytes("am force-stop " + packageInfo.packageName + "\n");nonsu.flush();
							nonsu.writeBytes("am kill " + packageInfo.packageName + "\n");nonsu.flush();
							nonsu.writeBytes("am kill-all \n");nonsu.flush();} catch (Exception e) {}
					}Toast.makeText(c, " cleaned", Toast.LENGTH_SHORT).show();
				}
			};
			thd.start();
			Runtime.getRuntime().exec("bash " + c.getDataDir() + "/gb.sh");
			System.runFinalization();
			Runtime.getRuntime().gc();
			System.gc();
			Runtime.getRuntime().runFinalization();
			Toast.makeText(c, "Done", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {}}

	public static void telg(Context c) {Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/GAMEbyF00Lr"));
		c.startActivity(i);}
		
	public static void Zram(String size){
		try {
			dtaoutput.writeBytes("echo " + size + " >/sys/block/zram0/disksize");
			dtaoutput.writeBytes("mkswap /data/zram0");
			dtaoutput.writeBytes("swapon  /data/zram0");
		} catch (IOException e) {}
	}
}
