package f00l.r;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.Service;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class c extends Service {
Switch s;
EditText cpum,mint,boost,stune;
	private Notification no;

	private View mFloatingView;

	private WindowManager mWindowManager;
    
    @Override
    public IBinder onBind(Intent intent) {
        
        return null;
    }
    public c(){}
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		no=new Notification.Builder(this,"idch").setSmallIcon(R.drawable.butterfly).setChannelId("idch").setShowWhen(false).build();
		startForeground(1,no);
		return START_FLAG_RETRY;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		if(Settings.canDrawOverlays(this)){
			int pa;
            
			Toast.makeText(this,"Proceed with extra caution",Toast.LENGTH_SHORT).show();
			if(Build.VERSION.SDK_INT>=27){
				pa=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
			}else{pa=WindowManager.LayoutParams.TYPE_PHONE;}
			mFloatingView = LayoutInflater.from(c.this).inflate(R.layout.cprime,null);
			WindowManager.LayoutParams paeams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
																			   WindowManager.LayoutParams.WRAP_CONTENT,
																			   pa,
																			   WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
																			   PixelFormat.TRANSLUCENT);
			paeams.gravity=Gravity.LEFT;
			mWindowManager= (WindowManager)getSystemService("window");
			mWindowManager.addView(mFloatingView,paeams);
			cpum=mFloatingView.findViewById(R.id.cpumax);
            cpum.setHint("CpuFreq");
			boost=mFloatingView.findViewById(R.id.boost);
			mint=mFloatingView.findViewById(R.id.sampletime);
			stune=mFloatingView.findViewById(R.id.stune);
		    s=mFloatingView.findViewById(R.id.cprimeSwitch);
			mint.setHint("GpuFreq");
			s.setChecked(getSharedPreferences("a",MODE_PRIVATE).getBoolean("cmanual",false));
			s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

					@Override
					public void onCheckedChanged(CompoundButton p1, boolean p2) {getSharedPreferences("a",MODE_PRIVATE).edit().putBoolean("cmanual",p2);
						if(!p2){mFloatingView.findViewById(R.id.cprimeLinearLayout).setVisibility(View.GONE);}else{mFloatingView.findViewById(R.id.cprimeLinearLayout).setVisibility(View.VISIBLE);}
					}
				});
			mFloatingView.findViewById(R.id.cprimeButton).setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View p1) {AlertDialog dialog = new AlertDialog.Builder(c.this)
							.setTitle("Are you sure?")
							.setMessage("Reboot will revert all changes.")
							.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dia, int which) {
									new Handler().postDelayed(new Runnable(){

											@Override
											public void run() {
												stopSelf();
											}
										}, 500);
									set();
								}
							})
							.setNegativeButton("No", new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface p1, int p2) {
									stopSelf();
								}
							})
							.create();
						dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
						dialog.show();
					}
				});
		}}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if(mWindowManager!=null){mWindowManager.removeView(mFloatingView);}
	}
	public void v(String cpum,String boost,int mint,String stune) throws Exception{Toast.makeText(getApplication(), "Done", Toast.LENGTH_SHORT).show();
		if (!cpum.isEmpty()) {
				pee.OnSuShell(" echo " +cpum+" > /sys/devices/system/cpu/cpufreq/policy*/scaling_setspeed");}
		if (!boost.isEmpty()) {
				pee.OnSuShell(" echo " + boost + " > /sys/devices/system/cpu/cpufreq/interactive/boost");}
		if (mint!=0) {
				pee.setgpufreq(mint,mint>6000,this);}
		if (!stune.isEmpty()) {
				pee.OnSuShell(" echo " + stune + " > /dev/stune/schedtune.boost");}
	}
    
    void set(){
        if(!s.isChecked()){return;}
//        if(cpum.getText().toString().isEmpty()){return;}
//        if(boost.getText().toString().isEmpty()){return;}
//        if(mint.getText().toString().isEmpty()){return;}
//        if(stune.getText().toString().isEmpty()){return;}
       	try {
			v(cpum.getText().toString(), boost.getText().toString(), Integer.valueOf(mint.getText().toString()), stune.getText().toString());
		} catch (Exception e) {}}
}
