package f00l.r;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.Surface;
import android.widget.Toast;

public class Screenrecorder extends Activity {

    private  final int REQUEST_CODE = 1000;
    private  int mScreenDensity;
    private  MediaProjectionManager mProjectionManager;
    private  int DISPLAY_WIDTH ;
    private  int DISPLAY_HEIGHT;
	private  int FPS;
	private  int Bitrate;
	int orientation;
	private  final SparseIntArray ORIENTATIONS = new SparseIntArray();
	{
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }
	public static String height="height",width="width",resulted="result",dencity="dencity",fps="fps",birate="bit",dataest="detatch",oreo="orio";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		SharedPreferences sp=getSharedPreferences("rec", MODE_PRIVATE);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();display.getRealSize(size);
        final int width =size.x;
	    final int height =size.y;
		orientation = ORIENTATIONS.get(display.getRotation() + 90);
		DISPLAY_HEIGHT = sp.getInt("resh", height);
		DISPLAY_WIDTH = sp.getInt("resw", width);
		FPS = sp.getInt("fps", 30);
		Bitrate = sp.getInt("bit", 512);
		mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mScreenDensity = metrics.densityDpi;
        request();
    }


	@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CODE) {
            return;
        }
        if (resultCode != RESULT_OK) {
            Toast.makeText(this, "Screen Cast Permission Denied", Toast.LENGTH_SHORT).show();
          	finish();
            return;
        }
		Intent intent=new Intent(this, vdo.class);
   		intent.putExtra(height, DISPLAY_HEIGHT);
		intent.putExtra(width, DISPLAY_WIDTH);
		intent.putExtra(resulted, resultCode);
		intent.putExtra(dencity, mScreenDensity);
		intent.putExtra(fps, FPS);
		intent.putExtra(birate, Bitrate);
		intent.putExtra(dataest, data);
		intent.putExtra(oreo, orientation);
		startForegroundService(intent);
		finish();

    }

	private void request() {
		startActivityForResult(mProjectionManager.createScreenCaptureIntent(), REQUEST_CODE);
	}

	
	
}
