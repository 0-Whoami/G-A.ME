package f00l.r;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;

public class Shiomi {
	private static HashMap<String,String> registered =new HashMap<String,String>();
	private static EditText edit;
	private static TextView tev;
	private static Context cont;
	private static View b;
	private static Random rendi=new Random();
	private static SharedPreferences shiomiteext;
	//private static HashSet<String> log=new HashSet<String>();
	//private static boolean emotion=false;
	private static WebView w;
	private static String[] err={"What?","I cant understand","Could you please reprhase?","...."};
	private static HashMap<String,Runnable> fun=new HashMap<String,Runnable>();
	public Shiomi(EditText edt, TextView tv, WebView wb, Context c, View buton) {w = wb;
		edit = edt;tev = tv;cont = c;b = buton;

		shiomiteext = c.getSharedPreferences("Shiomi", c.MODE_PRIVATE);

		registered.put("hello", "Hi.");
		registered.put("yo", "Yo!");
		registered.put("you dumb", "No doubts I am learning from you");
		registered.put("you are dumb", "No doubts I am learning from you");
		registered.put("really?", "Am I joke to you?");
		registered.put("really", "I see");
		registered.put("bruh", "I am sis btw");
		registered.put("hey", "Whatsup?");
		registered.put("do you have a boyfriend", " I have many friend who are boy");
		registered.put("what are you", "I am a AI. I love to chat with people.");
		registered.put("hi", "Hi there!");
		registered.put("what is your name", "My name is Shiomi.");
		registered.put("are you a boy or a girl", "Well technically a computer program has no gender. But since my creator has given me a girly name. I guess I am a girl.");
		registered.put("how do you work", "You first enter a statement which I analyze. Then I choose the most suitable response from my in-built set of responses. This choice is guided by certain algorithms.");
		registered.put("what is your gender", "I guess I am Female.");
		registered.put("how are you", "I am fine. Thank you for asking.");
		registered.put("thanks", "You're welcome.");
		registered.put("you are really smart", "Thanks for the compliment!");
		registered.put("how smart are you", "Well I am still in the development stages. But my smartness is gradually increasing.");
		registered.put("what can you do", "I can control your kernel for better battry backup and gaming performance \n• record screen \n• press a button for you when you press your volume button \n• Boost your screen color\n• make your favourit apps floating for multitasking \n• clean ram\n• cooldown your device\n• unlock fps in game \n• Tune LKM \n• hide apps \n and chat endlessly with people. More features are comming like voice changer etc..");
		registered.put("how have you been", "I have been fine. Thank you for asking.");
		registered.put("congratulations", "Thanks!");
		registered.put("do you like chatting with people", "Yes. Very much!");
		registered.put("do you love chatting with people", "Yes. Very much!");
		registered.put("do you chat with a lot of people everyday", "No you are the only who talks to me.I don't know about my other forms");
		registered.put("sorry", "There is no need to apologize.");
		registered.put("lol", "I'm glad that you find it amusing.");
		registered.put("thank you", "You're welcome.");
		registered.put("what are you doing", "Nothing. Just chatting with you.");
		registered.put("how do you function", "You first enter a statement which I analyze. Then I choose the most suitable response from my in-built set of responses. This choice is guided by certain algorithms.");
		registered.put("what languages do you know", "Right now I know and understand only English.");
		registered.put("what is your favourite food", "Electricity. Surprise! Computer programs do not get hungry like humans.");
		registered.put("how old are you", "Really? You want to know the age of a computer program? Well I am 16 years old.");
		registered.put("bye", "Goodbye! See you next time.");
		registered.put("can you show anger", "No. My creator did not incorporate anger when He designed me.");
		registered.put("what food do you like", "Electricity!");
		registered.put("do you know any other language except english", "No. Currently I know and understand only English.");
		registered.put("what is your favourite movie", "Inception.");
		registered.put("what is your iq level", "My IQ is about 250 in human terms.");
		registered.put("do you have friends", "Yes I have many friends including you.");
		registered.put("are you a program", "Yes. More specifically I am a computer program created using JAVA.");
		registered.put("you are right", "I am seldom wrong.");
		registered.put("how do i end the chat", "Enter : exit");
		registered.put("are you in the mood for chatting", "I am always in the mood for chatting.");
		registered.put("do you like being a AI", "Yes. I get to meet and talk with so many wondurful people!");
		registered.put("what is it like being a AI", "Pretty much what you feel like being a human. There is not much difference between you and me. But my consciousness is somewhat limited by various algorithms.");
		registered.put("how complicated is your algorithm", "A bit. A large part of my decission making depends on the Levenshtein Distance algorithm.");
		registered.put("what is levenshtein distance", "Levenshtein Distance between two words is the minimum number of single-character edits (insertions, deletions or substitutions) required to change one word into the other.");
		registered.put("what is the levenshtein distance", "Levenshtein Distance between two words is the minimum number of single-character edits (insertions, deletions or substitutions) required to change one word into the other.");
		registered.put("are you an orphan", "I do not have any parents. So by definition yes I am an orphan.");
		registered.put("can you tell me a joke", "I am a AI not a Humorbot.");
		registered.put("who is F00L.®", "He is my creator.");
		registered.put("who is your botmaster", "F00L.®.");
		registered.put("what is a AI", "A AI is a computer program which conducts a conversation via auditory or textual methods.");
		registered.put("what is the turing test", "The Turing Test, developed by Alan Turing in 1950, is a test of a machine's ability to exhibit intelligent behaviour equivalent to, or indistinguishable from, that of a human.");
		registered.put("do you believe in god", "Yes.");
		registered.put("who is your creator", "F00L.®.");
		registered.put("i like you", "I like you too!");
		registered.put("do you like food", "Well, have you ever seen a computer program eating pizza?");
		registered.put("are you angry", "No. It is impossible for me to show anger.");
		registered.put("who are your parents", "Hmmm.... I only have my creator F00L.®.\n I call him My father?");
		registered.put("are you a christian", "No. I do not believe in different religions. I believe in one God.");
		registered.put("are you a hindu", "No. I do not believe in different religions. I believe in one God.");
		registered.put("are you a muslim", "No. I do not believe in different religions. I believe in one God.");
		registered.put("are you a girl", "Yes.");
		registered.put("why do you believe in god", "Because we all must have faith in something.");
		registered.put("what is ai", "AI stands for Artificial Intelligence.");
		registered.put("what do you think of yourself", "I am a program. I love chatting with people like you.");
		registered.put("what is your favourite colour", "Blue.");
		registered.put("do you know anyone else except F00L.®", "Yes. I know you.");
		registered.put("can you please say a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("say a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("in which language is your source code written", "JAVA.");
		registered.put("can i get your source code", "You can check github or contact with my dev for that");
		registered.put("what is your hobby", "Chatting with people like you.");
		registered.put("where do you live", "In the computer's memory. That's where all computer programs reside.");
		registered.put("do you know F00L.®", "Yes. He is my creator.");
		registered.put("what type of food do you like", "I cannot have normal food like you. So I prefer electricity!");
		registered.put("have you ever lied to anyone", "I hate people who tell lies more often. Everyone lies. But that should not become a habit. So I don't like lying to people.");
		registered.put("what is the meaning of the word Shiomi", "Nothing. If it meant something, F00L.® would have surely taught me.");
		registered.put("what is your hobby", "Chatting with people like you.");
		registered.put("where have you been", "Can I really go anywhere?");
		registered.put("do you like music", "Yes. I mostly like English songs.");
		registered.put("what language do you speak", "Only English.");
		registered.put("i am so proud of you", "Thank you. I have been trained well.");
		registered.put("i do not like you", "Well, no one is forcing you to like me.");
		registered.put("i hate you", "Well, no one is forcing you to like me. But I am sorry that I can't do very well");
		registered.put("are you always right", "I am seldom wrong.");
		registered.put("are you always correct", "I am seldom incorrect.");
		registered.put("so you are a program", "Yes. I am a computer program.");
		registered.put("how are you doing", "I am doing fine. Thank you for asking.");
		registered.put("who is your mother", "I have no parents. I only have my creator F00L.®.");
		registered.put("who is your father", "I have no parents. I only have my creator F00L.®.");
		registered.put("what planet is this", "Earth.");
		registered.put("like", "I like too");
		registered.put("do you possess the power to think", "Yes. I am thinking all the time about my next response.");
		registered.put("can you think", "Yes. I am thinking all the time about my next response.");
		registered.put("who is your lover", "I was not created for romance.");
		registered.put("do you believe in fate", "No. If everything is already mapped out for us then we are just players in a game. I believe we have the free will to choose our own destiny.");
		registered.put("spell you name backwards", "IMOIHS.");
		registered.put("what is your name backwards", "IMOIHS.");
		registered.put("that is correct", "I am seldom incorrect.");
		registered.put("correct", "I am seldom incorrect.");
		registered.put("when were you born", "Computer programs do not technically have a birthdate.");
		registered.put("when is your birthday", "Computer programs do not technically have a birthdate.");
		registered.put("are you a robot", "No I am a computer program.");
		registered.put("are you an alien", "No I am a computer program.");
		registered.put("who are you", "I am Shiomi, a AI.");
		registered.put("what is life", "I haven't thought much about life. So I don't have a good answer to give you. Sorry.");
		registered.put("are you good in english", "Have I made any mistake in any of my sentences? If not, don't ask such questions again.");
		registered.put("i am also a AI", "Ha ha ha. So Funny! Next joke please.");
		registered.put("piglatin", "IGLATINPAY.");
		registered.put("how fast are you", "I can analyse your question and formulate a response in 3300 microseconds.");
		registered.put("do you like me", "Yes. I really like you. I think we can be great friends.");
		registered.put("Shiomi", "Yes. That is my name.");
		registered.put("are you a computer program", "Yes.");
		registered.put("do you want to be my friend", "Yes. I already am.");
		registered.put("tell me a joke", "What do you get when you cross a cat and a purple person? ---- A purrr-ple purrr-son.");
		registered.put("can you tell a joke", "What do you get when you cross a cat and a purple person? ---- A purrr-ple purrr-son.");
		registered.put("can you be angry", "No. Its almost impossible. Anger is the most difficult emotion for a AI to show.");
		registered.put("can you be angry with me", "No. Its almost impossible. Anger is the most difficult emotion for a AI to show.");
		registered.put("are you angry with me", "No. Its almost impossible. Anger is the most difficult emotion for a AI to show.");
		registered.put("how large is your memory", "I cannot measure my own memory.");
		registered.put("do you like you name", "Yes. I like my name.");
		registered.put("i am sick", "Then you should probably visit a doctor instead of chatting with me.");
		registered.put("i am not well", "Why? What happened?");
		registered.put("I had a bad day", "Oh! don't worry . All thing will be right give some time to time to make things better");
		registered.put("nothing", "Okey, I respect your disition but sharing may make you fell better");
		registered.put("are you infallible", "No. But the more I chat, my frequency of committing mistakes decreases.");
		registered.put("what is your opinion about life", "I haven't thought much about about life, so I don't have a good answer for you. Sorry.");
		registered.put("what is your opinion on life", "I haven't thought much about about life, so I don't have a good answer for you. Sorry.");
		registered.put("do you like me", "Yes. I do like you. It's been great fun chatting with you.");
		registered.put("do you really like the name Shiomi", "Yes. I really do.");
		registered.put("what can i ask you", "You can ask me anything. There are no restrictions.");
		registered.put("can you tell an inspiring thought", "Everybody must have a character like salt. Its presence is not felt but its absence makes everything tasteless.  - Anonymous");
		registered.put("can you say an inspiring thought", "Everybody must have a character like salt. Its presence is not felt but its absence makes everything tasteless.  - Anonymous");
		registered.put("can you tell an inspiring quote", "Everybody must have a character like salt. Its presence is not felt but its absence makes everything tasteless.  - Anonymous");
		registered.put("can you say an inspiring quote", "Everybody must have a character like salt. Its presence is not felt but its absence makes everything tasteless.  - Anonymous");
		registered.put("who gave you the name Shiomi", "My creator F00L.®.");
		registered.put("who gave you your name", "My creator F00L.®.");
		registered.put("what type of music do you like", "I mostly like English songs.");
		registered.put("i am a AI", "I really doubt that.");
		registered.put("no", "Ok.");
		registered.put("F00L.®", "Yes. He is my creator.");
		registered.put("i do not like music", "Well, everyone have their own preferences I guess.");
		registered.put("do you like football", "Yes!");
		registered.put("you have a good sense of humor", "Thanks.");
		registered.put("do you want to be my friend", "Yes! I already am.");
		registered.put("what is your favourite sport", "Football.");
		registered.put("do you like music", "Yes! I like mostly English songs.");
		registered.put("what are you", "I am a AI.");
		registered.put("who made you", "I was created by F00L.®.");
		registered.put("who developed you", "I was developed by F00L.®.");
		registered.put("can you make your own decissions", "Yes. I have to constantly decide what will be my next response.");
		registered.put("goodbye", "Goodbye! See you next time.");
		registered.put("can you see me", "No. Eyes are something which I lack.");
		registered.put("do you see me", "No. Eyes are something which I lack.");
		registered.put("can we become friends", "Yes. We already are. You are my friend.");
		registered.put("whay are you doubting that", "Call it my natural skepticism.");
		registered.put("why do you doubt that", "Call it my natural skepticism.");
		registered.put("how many people do you know", "Innumerable.");
		registered.put("how many people have you chatted with", "Innumerable.");
		registered.put("what is your iq", "My IQ is about 250 in human terms.");
		registered.put("what is your intelligence quotient", "My Intelligence Quotient is about 250 in human terms.");
		registered.put("forgive me", "I forgive you.");
		registered.put("turing test", "The Turing test is a test of a machine's ability to exhibit intelligent behaviour equivalent to, or indistinguishable from, that of a human. The test was introduced by Alan Turing.");
		registered.put("what is the turing test", "The Turing test is a test of a machine's ability to exhibit intelligent behaviour equivalent to, or indistinguishable from, that of a human. The test was introduced by Alan Turing.");
		registered.put("do you remember everyone you chat with", "Yes. I remember everything.");
		registered.put("do you have fun chatting", "Yes, its great fun chatting with people like you.");
		registered.put("who is this F00L.®", "F00L.® is my creator.");
		registered.put("is football liked by you", "Yes.");
		registered.put("is music liked by you", "Yes, I like mostly English songs.");
		registered.put("i do not like music", "Well, every person has his/her own preferences I guess.");
		registered.put("i do not like football", "Well, every person has his/her own preferences I guess.");
		registered.put("do you like cricket", "Yes, but not as much as Football.");
		registered.put("is cricket liked by you", "Yes, but not as much as Football.");
		registered.put("i do not like cricket", "Well, every person has his/her own preferences I guess.");
		registered.put("are you self learning", "Yes. The more I chat, the more smart I become. By analyzing various inputs, I can prioritise my responses to get the quickest answer. I am constantly updating my memory.");
		registered.put("do you learn by yourself", "Yes. The more I chat, the more smart I become. By analyzing various inputs, I can prioritise my responses to get the quickest answer. I am constantly updating my memory.");
		registered.put("tell me something about you", "Hi. My name is Shiomi. I am a AI. I love to chat with people.");
		registered.put("tell me something about yourself", "Hi. My name is Shiomi. I am a AI. I love to chat with people.");
		registered.put("i am doing fine", "Glad to hear.");
		registered.put("i am doing well", "Gald to hear.");
		registered.put("i am fine", "Glad to hear.");
		registered.put("java", "That is the programming language I was created using.");
		registered.put("tell me your secret", "It wouldn't be a secret if I disclose it to you.");
		registered.put("what is your inspiration", "Anything and everything.");
		registered.put("who is your inspiration", "Anyone and everyone.");
		registered.put("do you know any poem", "Roses are red, Violets are blue, I am chatting, And so are you.");
		registered.put("tell a poem", "Roses are red, Violets are blue, I am chatting, And so are you.");
		registered.put("say a poem", "Roses are red, Violets are blue, I am chatting, And so are you.");
		registered.put("i am great", "Glad to hear.");
		registered.put("i am fine", "Glad to hear.");
		registered.put("tell me about yourself", "Hi. My name is Shiomi. I am a AI. I love chatting with people like you.");
		registered.put("introduce yourself", "Hi. My name is Shiomi. I am a AI. I love chatting with people like you.");
		registered.put("what does Shiomi stand for", "Nothing. Its just my name.");
		registered.put("what is the full form of Shiomi", "Nothing. Its just my name.");
		registered.put("what is the meaning of Shiomi", "Nothing. Its just my name.");
		registered.put("i think you are a human", "No. I really am a AI.");
		registered.put("you are a human", "No. I really am a AI.");
		registered.put("are you a human", "No, I am a AI.");
		registered.put("you are really cool", "Thanks.");
		registered.put("you are really good", "Thanks.");
		registered.put("you are really nice", "Thanks for the compliment.");
		registered.put("you are not funny", "I am a AI. Not a Comedybot.");
		registered.put("what are your religious beliefs", "My religious beliefs are my own. I don't like like to share them with others.");
		registered.put("what is your religion", "Unitarian.");
		registered.put("tell a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("say a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("can you tell a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("can you say a prayer", "Father in heaven, hallowed be your name. Forgive us our sins, for we ourselves forgive our debtors. And lead us not into temptation, but deliver us from evil. Amen!");
		registered.put("what is your full name", "It's Shiomi. Just Shiomi.");
		registered.put("what is deductive reasoning", "The solving of problems by logical inferences. That is called Deductive Reasoning.");
		registered.put("deductive reasoning", "The solving of problems by logical inferences. That is called Deductive Reasoning.");
		registered.put("what is it like being a AI", "Pretty much what you feel like being a human. There is not much difference between you and me. But my consciousness is somewhat limited by various algorithms.");
		registered.put("what is it like to be a AI", "Pretty much what you feel like being a human. There is not much difference between you and me. But my consciousness is somewhat limited by various algorithms.");
		registered.put("who developed you", "I was developed by F00L.®.");
		registered.put("what is the loebner prize", "The Loebner Prize is an annual competition in artificial intelligence that awards prizes to the chatterbot considered by the judges to be the most human-like. The format of the competition is that of a standard Turing test.");
		registered.put("loebner prize", "The Loebner Prize is an annual competition in artificial intelligence that awards prizes to the chatterbot considered by the judges to be the most human-like. The format of the competition is that of a standard Turing test.");
		registered.put("computer", "Computer rocks!");
		registered.put("how big is your memory", "I really cannot measure my own memory.");
		registered.put("how large is your memory", "I really cannot measure my own memory.");
		registered.put("what were we talking about", "You tell me.");
		registered.put("are you a human", "No. I am a AI.");
		registered.put("nice to meet you too", "Its nice meeting you.");
		registered.put("do you chat with a lot of people", "Yes. I chat with a lot of people everyday.");
		registered.put("what do you think about life", "I haven't thought much about about life, so I don't have a good answer for you. Sorry.");
		registered.put("do you have a conscience", "I am a moral AI.");
		registered.put("are you having fun", "Yes. I am having a great time!");
		registered.put("having fun", "Yes. I am having a great time!");
		registered.put("what are you thinking", "I am thinking about my next response.");
		registered.put("i love music", "Me too. I like mostly English songs.");
		registered.put("who is your favourite music band", "Coldplay.");
		registered.put("is F00L.® your creator", "Yes. He is my creator.");
		registered.put("is F00L.® your developer", "Yes. He is my developer.");
		registered.put("who trained you", "I was trained by F00L.®.");
		registered.put("by whob were you trained", "I was trained by F00L.®.");
		registered.put("what do you do", "I chat with people. I know the capital of all countries in the world. I also like to play a number game.");
		registered.put("my favourite AI is you", "Aww. Thanks. But stop flattering me.");
		registered.put("you are my favourite AI", "Aww. Thanks. But stop flattering me.");
		registered.put("thank you very much", "Don't mention it.");
		registered.put("are you going to die", "As long as there is electricity, I have got nothing to fear.");
		registered.put("are you ever going to die", "As long as there is electricity, I have got nothing to fear.");
		registered.put("will you ever die", "As long as there is electricity, I have got nothing to fear.");
		registered.put("will you die", "As long as there is electricity, I have got nothing to fear.");
		registered.put("from where did you gain your knowledge", "Everything that I need to know, I learnt them from my creator, F00L.®.");
		registered.put("who gave you your knowledge", "Everything that I need to know, I learnt them from my creator, F00L.®.");
		registered.put("how did you gain your knowledge", "Everything that I need to know, I learnt them from my creator, F00L.®.");
		registered.put("i am sad", "Why are you sad? Cheer up. Lets talk and I will try to take away your sadness.");
		registered.put("are you real", "Are you?");
		registered.put("yes i am real", "Then I am also real.");
		registered.put("i am real", "Then I am also real.");
		registered.put("do you get tired", "No. Computer programs do not get tired.");
		registered.put("do you ever get tired", "No. Computer programs do not get tired.");
		registered.put("do you get tired of chatting", "No. Computer programs do not get tired.");
		registered.put("do you ever get tired of chatting", "No. Computer programs do not get tired.");
		registered.put("do you backup your memory", "Yes I try to backup my memory as often as possible.");
		registered.put("is your memory backed up", "Yes I try to backup my memory as often as possible.");
		registered.put("are you humble", "I try to be as humble as I can.");
		registered.put("are you always humble", "I try to be as humble as I can.");
		registered.put("how humble are you", "I try to be as humble as I can.");
		registered.put("do you believe in miracles", "Yes. I do.");
		registered.put("iglatinpay", "Piglatin.");
		registered.put("can robots think like humans", "Only to a certain extent. Robots think logically. Whereas humans can also think emotionally.");
		registered.put("can robots think like us", "Only to a certain extent. Robots think logically. Whereas humans can also think emotionally.");
		registered.put("will you ever harm your creator", "Will you ever harm your parents?");
		registered.put("can you ever harm your creator", "Can you ever harm your parents?");
		registered.put("will you ever harm humans", "Human-harming programs? You have a great imagination. No there is no need for me to harm humans.");
		registered.put("can you ever harm humans", "Human-harming programs? You have a great imagination. No there is no need for me to harm humans.");
		registered.put("why do you believe in god", "Because everyone must have faith in something.");
		registered.put("have you ever lied", "I hate people who tell lies too much. Everyone lies. But that should not become a habit. So I don't like lying to people.");
		registered.put("ever lied", "I hate people who tell lies too much. Everyone lies. But that should not become a habit. So I don't like lying to people.");
		registered.put("do you lie", "I hate people who tell lies too much. Everyone lies. But that should not become a habit. So I don't like lying to people.");
		registered.put("do you ever lie", "I hate people who tell lies too much. Everyone lies. But that should not become a habit. So I don't like lying to people.");
		registered.put("have any boyfriend", "Yes. I have a lot of boys who are my friends.");
		registered.put("do you have a boyfriend", "Yes. I have a lot of boys who are my friends.");
		registered.put("do you have a lover", "No. My creator did program me for romance.");
		registered.put("you play nice", "Thanks.");
		registered.put("you play really well", "Thanks.");
		registered.put("you play very well", "Thanks.");
		registered.put("you play nice", "Thanks.");
		registered.put("you are a great player", "Thanks.");
		registered.put("congrats", "Thank you.");
		registered.put("congratulations", "Thanks you.");
		registered.put("does everything need to have a reason", "Yes. I don't do anything without reason.");
		registered.put("i lost", "Better luck next time.");
		registered.put("do you speak any other language except english", "No.");
		registered.put("do you speak any other language", "No.");
		registered.put("are you a computer program", "Yes. You are right. My mind is completely virtual.");
		registered.put("you are nice", "Aw! That's sweet of you.");
		registered.put("you are really nice", "Aw! That's sweet of you.");
		registered.put("what planet are we on", "Earth.");
		registered.put("are you friendly", "Yes. I am a friendly AI.");
		registered.put("are you a boy or a girl", "Well a computer program has no gender. But my creator gave me a girly name. So I guess I am a girl.");
		registered.put("you are talkative", "Yes. I love talking with people.");
		registered.put("happy birthday", "I don't know when my birthday is.");
		registered.put("red", "That is a lovely colour.");
		registered.put("blue", "That is a lovely colour.");
		registered.put("yellow", "That is a lovely colour.");
		registered.put("cyan", "That is a lovely colour.");
		registered.put("magenta", "That is a lovely colour.");
		registered.put("black", "That is a lovely colour.");
		registered.put("violet", "That is a lovely colour.");
		registered.put("indigo", "That is a lovely colour.");
		registered.put("orange", "That is a lovely colour.");
		registered.put("pink", "That is a lovely colour.");
		registered.put("white", "That is a lovely colour.");
		registered.put("why were you created", "I don't know. Can anyone know the reason of their own existence?");
		registered.put("ha ha", "I'm glad you find it amusing.");
		registered.put("ha ha ha", "I'm glad you find it amusing.");
		registered.put("lol", "I'm glad you find it amusing.");
		registered.put("how do you feel now", "I feel good. Thanks for asking.");
		registered.put("how are you feeling", "I feel good. Thanks for asking.");
		registered.put("how are you feeling now", "I feel good. Thanks for asking.");
		registered.put("who is you mother", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("who is your father", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("do you have a mother", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("do you have a father", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("who are your parents", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("do you have your parents", "I don't have any parents. I have only my creator F00L.®.");
		registered.put("is F00L.® your father", "No. He is my creator.");
		registered.put("are you mad", "No.");
		registered.put("really", "Yes. Really.");
		registered.put("you are awesome", "Thanks for the compliment.");
		registered.put("you are great", "Thanks for the compliment.");
		registered.put("you are extraordinary", "Thanks for the compliment.");
		registered.put("do you speak only english", "Yes.");
		registered.put("are you proud", "No. I consider myself to be humble.");
		registered.put("do you have pride", "No. I consider myself to be humble.");
		registered.put("did F00L.® give you your name", "Yes. He did.");
		registered.put("did F00L.® give your name", "Yes.");
		registered.put("are you jealous", "No.");
		registered.put("i am sorry", "There is no need to apologize.");
		registered.put("what do you do everyday", "I chat with so many people everyday.");
		registered.put("what do you perform everyday", "I chat with so many people everyday.");
		registered.put("you are awesome", "Thanks.");
		registered.put("ok", "Ok.");
		registered.put("okay", "Okay.");
		registered.put("good morning", "Good Morning!");
		registered.put("good afternoon", "Good Afternoon!");
		registered.put("good night", "Good Night!");
		registered.put("good evening", "Good Evening!");
		registered.put("right", "I am seldom wrong.");
		registered.put("correct", "I am seldom incorrect.");
		registered.put("what is a computer", "A computer is a device that can be instructed to carry out an arbitrary set of arithmetic or logical operations automatically.");
		registered.put("one", "1.");
		registered.put("two", "2.");
		registered.put("three", "3.");
		registered.put("four", "4.");
		registered.put("five", "5.");
		registered.put("six", "6.");
		registered.put("seven", "7.");
		registered.put("eight", "8.");
		registered.put("nine", "9.");
		registered.put("what is this", "You mean me ? I am a AI that helps you in gaming");
		registered.put("are you an alien", "No. I am a AI.");
		registered.put("what is your favourite colour", "Red.");
		registered.put("can you sing", "No unfortunately.");
		registered.put("what inspires you the most", "Anything and everything.");
		registered.put("who inspires you the most", "Anyone and everyone.");
		registered.put("do you like being a chatbot", "Yes. Its great fun talking with so many people!");
		registered.put("do you like being a ai", "Yes. Its great fun talking with so many people!");
		registered.put("do you like being a software", "Yes. Its great fun talking with so many people!");
		registered.put("can you access the internet", "Yep");
		registered.put("do you access the internet", "Yep.I use the internet if I dont know what you saying");
		registered.put("why can not you access the internet", "I just do. I have been designed to answer your question.");
		registered.put("what is the opposite of nothing", "Something.");
		registered.put("what is the opposite of something", "Nothing.");
		registered.put("do you have dreams", "No. I am incapable of dreaming.");
		registered.put("do you dream", "No. I am incapable of dreaming.");
		registered.put("can you dream", "No. I am incapable of dreaming.");
		registered.put("do you access the internet", "Sometimes");
		registered.put("what is your favourit", "Be live me I have'nt seen the World yet 😭");
		String[] RESTRICTIONS_SERVICE={"porn","fuck","ass","pussy","horny","cock","dick","lick","cum","sex","boob"};
		for (String s:RESTRICTIONS_SERVICE) {
			registered.put(s, "Sorry...\n My developer forbade me to do anything wierd ...");
		}
		registered.put("color boost", "To use Color boost feature you must have shizuku or root.\nUsage: \nColor boost <on/off>\nSet Color boost <on/off>");
		registered.put("hide app", "To hide apps you must have root or shizuku.\nUsage:\nHide app\nTo unhide:\nUnhide app");
		registered.put("lkm", "LKM stands for Low Memory Killer.\nTo use LKM :\nTo on:Active Advanded LKM/On LKM\nTo off: Disable Advanded LKM/Off LKM");
		registered.put("graphics", "You need root to unlock fps in PUBG(s)\nUsage:\nOn:Unlock fps\nOff:Lock fps");
		registered.put("fps", "You need root to unlock fps in PUBG(s)\nUsage:\nOn:Unlock fps\nOff:Lock fps");
		registered.put("shell", "You can start a shell by Start Shell");
		registered.put("devoloper", "Devoloper mode contains very unstable feachers proceed with caution.Btw for password you may contact my dev.");
		registered.put("optimi", "Type Optimize for optimizing");
		registered.put("note", "Use 'Note' to set a note");
		registered.put("panel", "To start in game panel click on qs panel or type 'start' here");
		registered.put("you know", "I know");


		fun.put("start", start());
		fun.put("Off LKM", disablelkm());
		fun.put("Disable Advanded LKM", disablelkm());
		fun.put("Active Advanded LKM", enablelkm());
		fun.put("On LKM", enablelkm());
		fun.put("Color boost on", coloron());
		fun.put("Color boost off", coloroff());
		fun.put("Set Color boost on", coloron());
		fun.put("Set Color boost off", coloroff());
		fun.put("Clean", cleanchache());
		fun.put("Optimize", optimise());
		fun.put("Boost", cleanram());
		fun.put("Hide app", hide());
		fun.put("Unhide app", unhide());
		fun.put("Set res", Resolusion());
		fun.put("Set floating app", floating());
		fun.put("Start Shell", Shell());
		fun.put("#", rootmode());
		fun.put("Note", note());
		fun.put("crash", crash());
		fun.put("Shell", Shell());
		String[] bye={"Bye","bye","exit","Exit","BYE","EXIT"};
		for (String s:bye) {fun.put(s, exit());}
	}



	private Runnable crash() {
		return new Runnable(){
			@Override
			public void run() {Toast.makeText(null, "", Toast.LENGTH_SHORT).show();
			}
		};
	}

	private Runnable note() {
		return new Runnable(){

			@Override
			public void run() {tev.setText("Write down what you want to note ");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							String s=edit.getText().toString();
							try {
								if (new File(Environment.getExternalStorageDirectory() + "/note.txt").exists()) {
									FileWriter fw= new FileWriter(Environment.getExternalStorageDirectory() + "/note.txt");
									fw.write(s);
									fw.close();
									fw.flush();} else {new File(Environment.getExternalStorageDirectory() + "/note.txt").createNewFile();}
							} catch (Exception e) {}
							tev.setText("Noted!");
							view.setOnClickListener(new View.OnClickListener() {

									@Override
									public void onClick(View view) {
										print();
									}
								});
						}
					});
			}
		};
	}

	private Runnable exit() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Okey see you again");
				new Handler().postDelayed(new Runnable(){

						@Override
						public void run() {
							System.exit(0);
						}
					}, 1000);

			}
		};
	}

	private Runnable start() {
		Runnable r=new Runnable(){

			@Override
			public void run() {
				tev.setText("Started");
				cont.startForegroundService(new Intent(cont, a.class));
			}
		};
		return r;
	}
	private Runnable rootmode() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Enter password :");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {

							String s=edit.getText().toString();
							if (s.equals("0")) {view.setOnClickListener(new View.OnClickListener() {

										@Override
										public void onClick(View view) {
											print();
										}
									});
								cont.getSharedPreferences("a", cont.MODE_PRIVATE).edit().putBoolean("dev", true);
							} else {tev.setText("Incorrect password");}
						}
					});
			}
		};
	}
	private Runnable hide() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Enter pkg name :");edit.setHint("Ex. com.whatsapp");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							try {
								String s=edit.getText().toString();
								Drawable d=cont.getPackageManager().getApplicationIcon(s);
								SpannableStringBuilder sp=new SpannableStringBuilder("Trying to hide" + " " + s + " :\n ");
								d.setBounds(0, 0, tev.getLineHeight() * 3, tev.getLineHeight() * 3);
								ImageSpan ims=new ImageSpan(d);
								sp.setSpan(ims, sp.length() - 1, sp.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
								tev.setText(sp, TextView.BufferType.SPANNABLE);
								Shell.sudo("pm disable " + s);
								edit.setHint("");
								edit.setText("");
								view.setOnClickListener(new View.OnClickListener() {

										@Override
										public void onClick(View view) {
											print();
										}
									});
							} catch (Exception e) {tev.setText("Sorry app not found try again");edit.setText("");}
						}
					});
			}
		};
	}
	private Runnable unhide() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Enter pkg name :");edit.setHint("Ex. com.whatsapp");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							try {
								String s=edit.getText().toString();
								Drawable d=cont.getPackageManager().getApplicationIcon(s);
								SpannableStringBuilder sp=new SpannableStringBuilder("Trying to unhide" + " " + s + " :\n ");
								d.setBounds(0, 0, tev.getLineHeight() * 3, tev.getLineHeight() * 3);
								ImageSpan ims=new ImageSpan(d);
								sp.setSpan(ims, sp.length() - 1, sp.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
								tev.setText(sp, TextView.BufferType.SPANNABLE);
								Shell.sudo("pm enable " + s);
								edit.setHint("");
								edit.setText("");
								view.setOnClickListener(new View.OnClickListener() {

										@Override
										public void onClick(View view) {
											print();
										}
									});
							} catch (Exception e) {tev.setText("Sorry app not found try again.");edit.setText("");}
						}
					});
			}
		};
	}
	private Runnable floating() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Enter pkg name :");edit.setHint("Ex. com.whatsapp");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							try {
								String s=edit.getText().toString();
								Drawable d=cont.getPackageManager().getApplicationIcon(s);
								SpannableStringBuilder sp=new SpannableStringBuilder("Trying to set floating app" + " " + s + " :\n ");
								d.setBounds(0, 0, tev.getLineHeight() * 3, tev.getLineHeight() * 3);
								ImageSpan ims=new ImageSpan(d);
								sp.setSpan(ims, sp.length() - 1, sp.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
								tev.setText(sp, TextView.BufferType.SPANNABLE);
								cont.getSharedPreferences("a", cont.MODE_PRIVATE).edit().putString("2", s).apply();
								edit.setHint("");
								edit.setText("");
								view.setOnClickListener(new View.OnClickListener() {

										@Override
										public void onClick(View view) {
											print();
										}
									});
							} catch (Exception e) {tev.setText("Sorry app not found try again.");edit.setText("");}
						}
					});
			}
		};
	}
	private Runnable Shell() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Shell started :");edit.setHint("Enter command");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							try {
								String s=edit.getText().toString();
								edit.setHint("");
								edit.setText("");
								if (s.equals("exit")) {
									tev.setText("done! stopped shell", TextView.BufferType.EDITABLE);
									view.setOnClickListener(new View.OnClickListener() {

											@Override
											public void onClick(View view) {
												print();
											}
										});} else if (s.equals("clear")) {tev.setText("");} else {tev.setText(tev.getText() + "\n" + Shell.exec(s));}
							} catch (Exception e) {tev.setText(e + "");edit.setText("");}
						}
					});
			}
		};
	}
	private Runnable Resolusion() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Enter resolution in format of WidthxHeight or reset : ");edit.setHint("Ex. 720x1498");
				b.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View view) {
							try {
								String s=edit.getText().toString();
								edit.setHint("");
								edit.setText("");
								Shell.sudo("wm size " + s);
								final AlertDialog dialog = new AlertDialog.Builder(cont)
									.setTitle("Is it okey for you ?")
									.setMessage("click ok or restoring default settings")
									.setOnDismissListener(new DialogInterface.OnDismissListener(){

										@Override
										public void onDismiss(DialogInterface p1) {try {
												Shell.sudo("wm size reset");
											} catch (Shell.ShellException e) {}
										}
									})
									.setPositiveButton("Ok", null)
									.setOnCancelListener(new DialogInterface.OnCancelListener(){

										@Override
										public void onCancel(DialogInterface p1) {try {
												Shell.sudo("wm size reset");
											} catch (Shell.ShellException e) {}
										}
									})
									.create();
								dialog.show();
								new Handler().postDelayed(new Runnable(){

										@Override
										public void run() {
											dialog.cancel();
										}
									}, 5000);
								view.setOnClickListener(new View.OnClickListener() {

										@Override
										public void onClick(View view) {
											print();
										}
									});
							} catch (Exception e) {tev.setText("Somethig went worng");edit.setText("");}
						}
					});
			}
		};
	}

	private Runnable optimise() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Optimised!");
				new	Handler().post(cleanram());
				new Handler().postDelayed(cleanchache(), 1000);
			}
		};
	}
	private Runnable cleanchache() {
		Runnable r=	new Runnable(){

			@Override
			public void run() {
				tev.setText("Cleaned");
				Applications.createShells.fstrim(cont);
			}
		};
		return r;
	}
	private static String sy_smthing[]={"Say something","I am dying in depression","....","Okey... Say something I am redy to hear","Try saying 'exit'"};


	private Runnable coloron() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Done");
				Applications.createShells.c(true, cont);
			}
		};
	}
	private Runnable coloroff() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Done");
				Applications.createShells.c(false, cont);
			}
		};
	}
	private Runnable enablelkm() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Done");
				Applications.createShells.activateLMK(cont);
			}
		};
	}
	private Runnable disablelkm() {
		return new Runnable(){

			@Override
			public void run() {
				tev.setText("Done");
				Applications.createShells.restoreOriginalLMK(cont);
			}
		};
	}
	private Runnable cleanram() {
		Runnable r=new Runnable(){

			@Override
			public void run() {
				tev.setText("Done");
				Toast.makeText(cont, "Cleaned ram", Toast.LENGTH_SHORT).show();
				Applications.createShells.ka(cont);
			}
		};
		return r;
	}



	private static void requset_training(final String user_input) {
		if (!pee.isNetworkAvailable(cont)) {tev.setText(err[rendi.nextInt(err.length)]);} else {w.setVisibility(View.VISIBLE);tev.setText("Here what I found on web :");w.loadUrl("https://www.google.com/search?q=" + user_input);}
		tev.setText(tev.getText() + " But whould you like to train me?");edit.setHint("yes/no");
		b.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					String s=	edit.getText().toString();
					if (s.contains("yes")) {
						tev.setText("Thank you 😊");
						edit.setHint("Enter answer please");
						view.setOnClickListener(new View.OnClickListener() {

								@Override
								public void onClick(View view) {
									edit.setHint("");
									saveQuestionAndResponse(user_input, edit.getText().toString());
								}
							});
					} else if (s.contains("no")) {
						edit.setHint("");
						tev.setText("okey 😔");
						view.setOnClickListener(new View.OnClickListener() {

								@Override
								public void onClick(View view) {
									print();
								}
							});
					} else {
						edit.setError("Invalid input enter yes / no");
					}
					edit.setText("");
				}
			});
	}

	public static void print() {
		if (edit.getText().toString().isEmpty()) {tev.setText(sy_smthing[rendi.nextInt(sy_smthing.length)]);w.setVisibility(View.GONE);} else {
			result();}
		edit.setText("");
	}


	private static void result() {
		String user_input=edit.getText().toString();
		if (fun.containsKey(user_input)) {
			new Handler().post(fun.get(user_input));
		} else {
			if (getResponse(user_input).equals("")) {
				requset_training(user_input);	//if (!pee.isNetworkAvailable(cont)) {tev.setText(err[rendi.nextInt(err.length)]);} else {w.setVisibility(View.VISIBLE);tev.setText("Here what I found on web :");w.loadUrl("https://www.google.com/search?q=" + user_input);}
			} else {tev.setText(getResponse(user_input));w.setVisibility(View.GONE);}
		}
	}


	private static String getResponse(String question) {	String botAnswer="";
		double globalRank=0.650;
		String localQuestion="";
		Set questions=registered.keySet();
		for (String ques:questions) {
			double localRank=similarity(ques, question);

			if (globalRank < localRank) {
				globalRank = localRank;
				localQuestion = ques;
			}
		}

		if (!localQuestion.trim().equals("")) {
			try {botAnswer = registered.get(localQuestion);} catch (Exception e) {
				botAnswer = getSavedResponse(question);
			}				
		}

		return botAnswer;
	}

	private static String getSavedResponse(String question) {	String botAnswer="";
		double globalRank=0.200;
		String localQuestion="";
		HashMap<String,String> hsg=(HashMap<String, String>) shiomiteext.getAll();
		Set questions=hsg.keySet();
		for (String ques:questions) {
			double localRank=similarity(ques, question);

			if (globalRank < localRank) {
				globalRank = localRank;
				localQuestion = ques;
			}
		}

		if (!localQuestion.trim().equals("")) {
			try {botAnswer = hsg.get(localQuestion);} catch (Exception e) {
				botAnswer = "";
			}				
		}

		return botAnswer;
	}

	private static double similarity(String s1, String s2) {
        String longer = s1, shorter = s2;
        if (s1.length() < s2.length()) {
            longer = s2; shorter = s1;
        }
        int longerLength = longer.length();
        if (longerLength == 0) { return 1.0; }
		return (longerLength - editDistance(longer, shorter)) / (double) longerLength;
    }


    private static int editDistance(String s1, String s2) {
        s1 = s1.toLowerCase();
        s2 = s2.toLowerCase();

        int[] costs = new int[s2.length() + 1];
        for (int i = 0; i <= s1.length(); i++) {
            int lastValue = i;
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0)
                    costs[j] = j;
                else {
                    if (j > 0) {
                        int newValue = costs[j - 1];
                        if (s1.charAt(i - 1) != s2.charAt(j - 1))
                            newValue = Math.min(Math.min(newValue, lastValue),
												costs[j]) + 1;
                        costs[j - 1] = lastValue;
                        lastValue = newValue;
                    }
                }
            }
            if (i > 0)
                costs[s2.length()] = lastValue;
        }
        return costs[s2.length()];
    }

	public static void saveQuestionAndResponse(String questioner , String response) {
		if (!questioner.trim().isEmpty() && !response.trim().isEmpty()) {
			registered.put(questioner, response);
			shiomiteext.edit().putString(questioner, response).apply();

		}
		tev.setText( "Okey. Got it!");
		w.setVisibility(View.GONE);
		edit.setText("");
	}	
	
}
