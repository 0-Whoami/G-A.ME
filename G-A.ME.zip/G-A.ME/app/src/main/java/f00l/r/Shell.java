package f00l.r;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Shell {

    public static enum OUTPUT {
        NONE, STDOUT, STDERR
        };

    private static OUTPUT sOStream = OUTPUT.STDOUT;

    private static enum SU_COMMAND {
        SU("su"),
        BIN("/system/bin/su"),
        XBIN("/system/xbin/su");

        private String mCmd;

        SU_COMMAND(String cmd) {
            mCmd = cmd;
        }

        public String getCommand() {
            return mCmd;
        }
    }

    private static enum UID_COMMAND {
        ID("id"),
        BIN("/system/bin/id"),
        XBIN("/system/xbin/id");

        private String mCmd;

        UID_COMMAND(String cmd) {
            mCmd = cmd;
        }

        public String getCommand() {
            return mCmd;
        }
    }

    private static String sShell;
    private static final String EOL = System.getProperty("line.separator");
    private static final String EXIT = "exit" + Shell.EOL;

    public static class ShellException extends Exception {

        public ShellException() {
            super();
        }

        public ShellException(String msg) {
            super(msg);
        }
    }

    private static class Buffer extends Thread {
        private InputStream mInputStream;
        private StringBuffer mBuffer;
        public Buffer(InputStream inputStream) {
            mInputStream = inputStream;
            mBuffer = new StringBuffer();
            this.start();
        }

        public String getOutput() {
            try {
                this.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return mBuffer.toString();
        }

        
        @Override
        public void run() {
            try {
                String line;
                BufferedReader reader = new BufferedReader(new InputStreamReader(mInputStream));
                if((line = reader.readLine()) != null) {
                    mBuffer.append(line);
                    while((line = reader.readLine()) != null) {
                        mBuffer.append(Shell.EOL).append(line);
                    }
                }
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }

    
    private Shell() {}

    
    private static String nativeExec(String cmd) throws ShellException {
        Process proc = null;
        Buffer buffer = null;
        try {
            proc = Runtime.getRuntime().exec(cmd);
            buffer = getBuffer(proc);
            proc.waitFor();
            return buffer.getOutput();
        } catch (Exception e) {
            throw new ShellException();
        }       
    }

    
    private static String suExec(String cmd) throws ShellException {
        try {
            Process proc = Runtime.getRuntime().exec(sShell);
            Buffer buffer = getBuffer(proc);
            DataOutputStream shell = new DataOutputStream(proc.getOutputStream());

            shell.writeBytes(cmd + Shell.EOL);
            shell.flush();
            shell.writeBytes(Shell.EXIT);
            shell.flush();
            proc.waitFor();
            return buffer.getOutput();

        } catch (Exception e) {
			
            throw new ShellException();
        }
    }

    
    private static void setSuShell() throws ShellException {
        for(SU_COMMAND cmd : SU_COMMAND.values()) {
            sShell = cmd.getCommand();
            if(Shell.isRootUid()) {
                return;
            }
        }
        sShell = null;
    }

    
    private static boolean isRootUid() throws ShellException {
        for(UID_COMMAND uid : UID_COMMAND.values()) {
            String output = Shell.sudo(uid.getCommand());
            if(output != null && output.length() > 0) {
                Matcher regex = Pattern.compile("^uid=(\\d+).*?").matcher(output);
                if(regex.matches()) {
                    if("0".equals(regex.group(1))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    
    private static Buffer getBuffer(Process proc) {
        Buffer buffer = null;
        switch(sOStream) {
            case NONE:
                new Buffer(proc.getInputStream());
                new Buffer(proc.getErrorStream());
                break;
            case STDOUT:
                buffer = new Buffer(proc.getInputStream());
                new Buffer(proc.getErrorStream());
                break;
            case STDERR:
                buffer = new Buffer(proc.getErrorStream());
                new Buffer(proc.getInputStream());
                break;
            default:
                return buffer;
        }
        return buffer;
    }

    
    synchronized public static void setOutputStream(Shell.OUTPUT ostream) {
        sOStream = ostream;
    }

    
    synchronized public static void setShell(String shell) {
        sShell = shell;
    }

    
    synchronized public static boolean su() {
        if(sShell == null) {
            try {
                Shell.setSuShell();
            } catch (ShellException e) {
                sShell = null;
            }
        }
        return sShell != null;
    }

    
    synchronized public static String sudo(String cmd) throws ShellException {
        if(Shell.su()) {
            return Shell.suExec(cmd);
        } else {
            return null;
        }

    }

    synchronized public static String exec(String cmd) throws ShellException {
        return Shell.nativeExec(cmd);
    }
}

