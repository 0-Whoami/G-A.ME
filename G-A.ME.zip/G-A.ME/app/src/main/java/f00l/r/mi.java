package f00l.r;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.icu.math.BigDecimal;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import f00l.r.mi;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

public class mi extends Service {
	private Notification no;
	TextView t;
	private View mFloatingView;
	private WindowManager mWindowManager;
    WindowManager.LayoutParams paeams;
	Handler h;
	Runnable runable;
    @Override
    public IBinder onBind(Intent intent) {
        
        return null;
    }
    public mi() {}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		no=new Notification.Builder(this,"idch").setSmallIcon(R.drawable.butterfly).setChannelId("idch").setShowWhen(false).build();
		startForeground(1,no);
		return START_FLAG_RETRY;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		int pa;
		if (Build.VERSION.SDK_INT >= 27) {
			pa=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
		}else{pa=WindowManager.LayoutParams.TYPE_PHONE;}
		mFloatingView = LayoutInflater.from(mi.this).inflate(R.layout.m,null);
		paeams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
																		   WindowManager.LayoutParams.WRAP_CONTENT,
																		   pa,
																		   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
																		   PixelFormat.TRANSLUCENT);
		paeams.gravity=Gravity.TOP;
		paeams.x=0;
		paeams.y=0;		
		mWindowManager= (WindowManager)getSystemService("window");
		mWindowManager.addView(mFloatingView,paeams);
		t=mFloatingView.findViewById(R.id.mTextView);
		mFloatingView.setOnTouchListener(new View.OnTouchListener(){

				final WindowManager.LayoutParams floatWindowLayoutUpdateParam = paeams; 

				double x; 

				double y; 

				double px; 

				double py; 



				@Override

				public boolean onTouch(View v, MotionEvent event) { 



					switch (event.getAction()) { 

						case MotionEvent.ACTION_DOWN: 

							x = floatWindowLayoutUpdateParam.x; 

							y = floatWindowLayoutUpdateParam.y; 

							px = event.getRawX(); 


							py = event.getRawY(); 

							break; 
						case MotionEvent.ACTION_MOVE: 

							floatWindowLayoutUpdateParam.x = (int) ((x + event.getRawX()) - px); 

							floatWindowLayoutUpdateParam.y = (int) ((y + event.getRawY()) - py); 

							mWindowManager.updateViewLayout(mFloatingView, floatWindowLayoutUpdateParam); 

							break; 

					} return false;}

			});
		h = new Handler();
		runable= new Runnable() {
                @Override
                public void run() {
				
					t.setText(" 🍀 "+ReadCPUinfo()+"Ghz"+" 🌡 ️"+thermalTemp()+"°C 💿 "+ram()+"mb "+" 🎞️ "+appon.gpuload() +"%");
                   try{ h.postDelayed(this, 5000);}catch(Exception e){}
                }
            };
			h.post(runable);}


	@Override
	public void onDestroy() {
		super.onDestroy();
		h.removeCallbacksAndMessages(runable);
		h=null;
		if(mWindowManager!=null){mWindowManager.removeView(mFloatingView);}
	}
	public float ReadCPUinfo() {
        float f = 0f;
        try {
            InputStream inputStream = new ProcessBuilder(new String[]{"/system/bin/cat", "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"}).start().getInputStream();
            byte[] bArr = new byte[1024];
            if (inputStream.read(bArr) != -1) {
                return new BigDecimal((double) (Float.parseFloat(new StringBuffer().append("").append(new String(bArr)).toString()) / 1000000.0f)).setScale(1, 6).floatValue();
            }
            inputStream.close();
            return f;
        } catch (IOException e) {
            e.printStackTrace();
            return f;
        }
    }
	public String ram(){
		MemoryInfo mi = new MemoryInfo();
		ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		activityManager.getMemoryInfo(mi);
		double availableMegs = mi.availMem / 0x100000L;
		String s=String.valueOf(availableMegs);
		return s;
	}
	public float thermalTemp() {
		try{RandomAccessFile reader = new RandomAccessFile("/sys/class/thermal/thermal_zone1/temp", "r");
			String line = reader.readLine();
			return Float.parseFloat(line)/1000;
		} catch (IOException e) {}
		return 0f;
    }
}
