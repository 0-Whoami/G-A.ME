package f00l.r;

import android.app.AlarmManager;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;
import java.util.Scanner;
import android.app.WallpaperColors;
public class Applications extends Application {
	private static Context context;
	public static pee createShells;
	private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
	@Override
	public void onCreate() {
		createShells = new pee();
		this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
				@Override
				public void uncaughtException(Thread thread, Throwable ex) {
					Intent intent = new Intent(getApplicationContext(), cr.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
					intent.putExtra("error", getStackTrace(ex));
					PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 11111, intent, PendingIntent.FLAG_ONE_SHOT);
					AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
					am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, pendingIntent);
					android.os.Process.killProcess(android.os.Process.myPid());
					System.exit(2);
					uncaughtExceptionHandler.uncaughtException(thread, ex);
				}
			});
		new Handler().post(new Runnable(){

				@Override
				public void run() {
					try {
//							SharedPreferences s=context.getSharedPreferences("gpudir", context.MODE_PRIVATE);
//							SharedPreferences.Editor se=s.edit();
//							String sr=  Shell.sudo("find / -name \"available_governors\" 2> /dev/null").replaceAll("available_governors", "");
//							sr.wait();
//							se.putString("gpudir", sr).apply();
//							
						lsap(context);
					} catch (Exception e) {}
				}
			});

		n();Applications.context = getApplicationContext();
		super.onCreate();
	}

	private void n() {
		if (Build.VERSION.SDK_INT >= 26) {
			NotificationChannel notificationChannel = new NotificationChannel("idch", "turn this off to hide notification", 1);
			notificationChannel.enableVibration(false);
			notificationChannel.enableLights(true);
			notificationChannel.setSound(null, null);
			try {
				((NotificationManager) getSystemService(Class.forName("android.app.NotificationManager"))).createNotificationChannel(notificationChannel);
			} catch (ClassNotFoundException e) {
			}
		}
	}public static Context getAppContext() {
		return Applications.context;
	}



	private void lsap(Context c)throws Exception {
		List<ApplicationInfo> packages;
		PackageManager pm;
		pm = c.getPackageManager();
		packages = pm.getInstalledApplications(0);
		FileWriter fw =new FileWriter(c.getDataDir() + "/gb.sh", true);
		new File(c.getDataDir() + "/gb.sh").createNewFile();
		if (!new Scanner(c.getDataDir() + "/gb.sh").nextLine().isEmpty()) {new FileWriter(c.getDataDir() + "/gb.sh").write("");}
		for (ApplicationInfo packageInfo : packages) {
			fw.write("am kill " + packageInfo.packageName + "\n");
			fw.write("am force-stop " + packageInfo.packageName + "\n");
		}fw.write("am kill-all");
	}

	private String getStackTrace(Throwable th) {
		final Writer result = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(result);
		Throwable cause = th;
		while (cause != null) {
			cause.printStackTrace(printWriter);
			cause = cause.getCause();
		}
		final String stacktraceAsString = result.toString();
		printWriter.close();
		return stacktraceAsString;
	}
	
}
