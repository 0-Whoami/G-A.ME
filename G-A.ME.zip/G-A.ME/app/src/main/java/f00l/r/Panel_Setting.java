package f00l.r;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.ToggleButton;
import f00l.r.new_a;
import java.util.HashSet;
import java.util.Set;

public class Panel_Setting extends Activity { 
	RelativeLayout r2;
	ImageView walpvied;
	View panlviw;
	String app1_name;
	String app2_name;
    public static LinearLayout ico;

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.Panel_set);
		if(bacteria.text==Color.BLACK){setTheme(R.style.AppThemeWhite);}else{setTheme(R.style.AppTheme);}
    }

    @Override
    protected void onResume() {
        super.onResume();
        ico = (LinearLayout)findViewById(R.id.icowere);
        walpvied = findViewById(R.id.PanelsetImageView2);
        final ToggleButton s1=findViewById(R.id.xlSwitch1);
        panlviw = findViewById(R.id.PanelsetImageView1);
        final EditText x=findViewById(R.id.xlEditText2X);
		final EditText y=findViewById(R.id.xlEditText2Y);
        final EditText edittext=new EditText(Panel_Setting.this);
        final ImageView iio=findViewById(R.id.PanelsetImageViewiio);
        final EditText floating=findViewById(R.id.xlEditText1);
        final RadioButton l=findViewById(R.id.xlwdl);
        final RadioButton r=findViewById(R.id.xlwdr);
        final ScrollView srv=findViewById(R.id.Panel_setScrollView);
        final ImageButton map=findViewById(R.id.PanelsetImageButton1);
        final EditText apps2=findViewById(R.id.xlapp2);
		final ImageView app2view=findViewById(R.id.PanelsetImageViewiio2);
        final SharedPreferences Sph=getSharedPreferences("a", MODE_PRIVATE);
		app1_name = Sph.getString("2", null);
		app2_name=Sph.getString("app2",null);
		
        final Bitmap b=((BitmapDrawable)getWallpaper()).getBitmap();
        final Bitmap bb=bacteria.blur(this, b);
        Drawable d=new BitmapDrawable(getResources(), bb);
        final int textcol=bacteria.getContrastColor(bacteria.getDominantColor(bb));
		
		//if (textcol == Color.BLACK) {setTheme(R.style.AppThemeWhite);} else {setTheme(R.style.AppTheme);}
        walpvied.setImageDrawable(getWallpaper());
		walpvied.setClipToOutline(true);
        x.setText(String.valueOf(Sph.getInt("tapX", 0)));
		y.setText(String.valueOf(Sph.getInt("tapY",0)));
        getWindow().getDecorView().setBackground(d);
        if (Sph.getBoolean("4", false)) {r.setChecked(true);panlviw.animate().y(400f).setDuration(1000);} else {l.setChecked(true);  panlviw.animate().y(40f).setDuration(1000);}
        r2 = findViewById(R.id.PanelsetRelativeLayout2);
        r2.setClipToOutline(true);
        floating.setText(app1_name);
		apps2.setText(app2_name);
        s1.setChecked(Sph.getBoolean("mans", true));
        if (Sph.getBoolean("mans", true)) {srv.setVisibility(View.VISIBLE);} else {srv.setVisibility(View.GONE);}
        
		try {
			iio.setImageDrawable(getPackageManager().getApplicationIcon(app1_name));
			iio.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View view) {
					startActivity(getPackageManager().getLaunchIntentForPackage(app1_name));
					}
				});
			app2view.setImageDrawable(getPackageManager().getApplicationIcon(app2_name));
			app2view.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View view) {
						startActivity(getPackageManager().getLaunchIntentForPackage(app1_name));
					}
				});
			} catch (PackageManager.NameNotFoundException e) {}
        fetch(this);
		
        ////######  Themeing

        new Handler().post(new Runnable(){

                @Override
                public void run() {
					s1.setTextColor(textcol);
					r.setTextColor(textcol);
					l.setTextColor(textcol);
                    r.getBackground().setColorFilter(textcol, PorterDuff.Mode.MULTIPLY);
                    l.getBackground().setColorFilter(textcol, PorterDuff.Mode.MULTIPLY);
                    s1.getBackground().setColorFilter(textcol, PorterDuff.Mode.MULTIPLY);
                }
            });
			
        //########interaction

        new Handler(Looper.getMainLooper()).post(new Runnable(){

                @Override
                public void run() {

					apps2.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                try {
                                    app2view.setImageDrawable(getPackageManager().getApplicationIcon(s.toString()));if (isInstalled(s.toString())) {Sph.edit().putString("app2", s.toString()).apply();}
                                } catch (PackageManager.NameNotFoundException e) {}
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });
                    map.setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                startActivity(new Intent(Panel_Setting.this, map.class));
                            }
                        });

                    s1.setOnCheckedChangeListener(new Switch.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                Sph.edit().putBoolean("mans", p2).apply();
                                if (p2) {srv.setVisibility(View.VISIBLE);} else {srv.setVisibility(View.GONE);}
                            }
                        });

                    y.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
          
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
								if(!s.toString().isEmpty()) { Sph.edit().putInt("tapY",Integer.valueOf(s.toString())).apply();}
                            }
                        });
						
					x.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                             
                            }

                            @Override
                            public void afterTextChanged(Editable s) {
								if(!s.toString().isEmpty())  {Sph.edit().putInt("tapX", Integer.valueOf(s.toString())).apply();}
                            }
                        });

                    floating.addTextChangedListener(new TextWatcher(){

                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                try {
                                    iio.setImageDrawable(getPackageManager().getApplicationIcon(s.toString()));if (isInstalled(s.toString())) {Sph.edit().putString("2", s.toString()).apply();}
                                } catch (PackageManager.NameNotFoundException e) {}
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });

                    findViewById(R.id.addico).setOnClickListener(new View.OnClickListener() {

                            @Override
                            public void onClick(View view) {
                                AlertDialog dialog = new AlertDialog.Builder(Panel_Setting.this)
                                    .setTitle("Add GAMEs")
                                    .setView(edittext)
                                    .setMessage("Enter app's package name which should be boosted on start")
                                    .setPositiveButton("Add", new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dia, int which) {
                                            svepkg(edittext.getText().toString(), null, Panel_Setting.this);fetch(Panel_Setting.this);
                                        }
                                    })
                                    .setNegativeButton("Cancel", null)
                                    .create();
                                dialog.show();
                            }
                        });

                    r.setOnCheckedChangeListener(new ToggleButton.OnCheckedChangeListener(){

                            @Override
                            public void onCheckedChanged(CompoundButton p1, boolean p2) {
                                Sph.edit().putBoolean("4", p2).apply();
                                if (p2) {panlviw.animate().y(380f).setDuration(1000);} else {panlviw.animate().y(40f).setDuration(1000);}
                            }
                        });

                }
            });
    }



    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    public static void svepkg(String s, ImageView v, Context c) {
        SharedPreferences.Editor e=c.getSharedPreferences("set", MODE_PRIVATE).edit();
        Set<String> set =c.getSharedPreferences("set", MODE_PRIVATE).getStringSet("set", new HashSet<String>());
        Set<String> set2=new HashSet<>();
        set2.addAll(set);
        set2.add(s);
        e.putStringSet("set", set2).apply();
        fetch(c);
        try {
            if (v != null) {v.setImageDrawable(c.getPackageManager().getApplicationIcon(s));}
        } catch (PackageManager.NameNotFoundException wie) {}
    }

    public static void fetch(final Context c) {
        if (ico == null) {ico = new LinearLayout(c);}
        ico.removeAllViewsInLayout();
        final Set<String> set =c.getSharedPreferences("set", MODE_PRIVATE).getStringSet("set", new HashSet<String>());
        for (final String s:set) {
            final ImageView i = new ImageView(c);
            ViewGroup.LayoutParams pat=new ViewGroup.LayoutParams(100, 100);
            i.setLayoutParams(pat);
            ico.addView(i);
            i.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        c.startActivity(new Intent(c.getPackageManager().getLaunchIntentForPackage(s)));
                    }
                });
            i.setOnLongClickListener(new View.OnLongClickListener() {

                    @Override
                    public boolean onLongClick(View view) {
                        ico.removeViewInLayout(view);
                        Set<String> set2=new HashSet<>();
                        set2.addAll(set);
                        set2.remove(s);
                        c.getSharedPreferences("set", MODE_PRIVATE).edit().putStringSet("set", set2).apply();
                        return false;
                    }
                });
            try {
                i.setImageDrawable(c.getPackageManager().getApplicationIcon(s));
            } catch (PackageManager.NameNotFoundException e) {}

        }

    }
	private boolean isInstalled(String toString) {
		try {
			getPackageManager().getApplicationIcon(toString);
			return true;
		} catch (PackageManager.NameNotFoundException e) {return false;}
	}
} 
