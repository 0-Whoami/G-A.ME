package f00l.r;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class btl extends BroadcastReceiver
	{

		@Override
		public void onReceive ( Context context, Intent intent )
			{
				//  PowerManager powerManager = (PowerManager)context.getSystemService(Context.POWER_SERVICE);
				if ( context.getSharedPreferences ( "twks", context.MODE_PRIVATE ).getBoolean ( "twks", true ) )
					{ if ( intent.getAction ( ).equals ( Intent.ACTION_BATTERY_LOW ) )
							{
								try
									{
										Applications.createShells.battry ( context );
									}
								catch (Exception e)
									{}
							}
						if ( intent.getAction ( ).equals ( Intent.ACTION_BATTERY_OKAY ) )
							{
								try
									{if ( Applications.createShells.ishmp ( ) )
											{Shell.sudo ( "echo interactive > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" );
											}
										else
											{Shell.sudo ( "echo schedutil > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" );}
										Shell.sudo ( "echo 1 > /sys/devices/system/cpu/cpu*/online" );}
								catch (Exception e)
									{}
							}}
			}

	}
