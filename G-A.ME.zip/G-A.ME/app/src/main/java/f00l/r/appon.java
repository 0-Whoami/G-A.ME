package f00l.r;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import java.util.HashSet;
import java.util.Set;

public class appon extends AccessibilityService {
    Set<String> set;
	@Override
	public void onAccessibilityEvent(AccessibilityEvent p1) {
		set = getSharedPreferences("set", MODE_PRIVATE).getStringSet("set", new HashSet<>());
        if (p1.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            for (String s:set) {  if (p1.getPackageName().equals(s)) {if (!isMyServiceRunning(a.class)) {
                        Applications.createShells.pb(s);	appon.this.startForegroundService(new Intent(appon.this, a.class));
					}

				} else {appon.this.stopService(new Intent(appon.this, a.class));}}
		} 
	}

	@Override
	public void onInterrupt() {
	}

    @Override
	protected void onServiceConnected() {
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
        info.notificationTimeout = 100;
        info.packageNames = null;
        setServiceInfo(info);
		final Handler h= new Handler();
		if (getSharedPreferences("twks", MODE_PRIVATE).getBoolean("twks", true)) {h.postDelayed(new Runnable(){

					@Override
					public void run() {
						try {
							aiload(getApplicationContext());
						} catch (Exception e) {}
						if (getSharedPreferences("twks", MODE_PRIVATE).getBoolean("twks", true)) {h.postDelayed(this, 5000);}
					}
				}, 1000);}

		// Toast.makeText(getApplication(), getCpuUsage(getApplicationContext()) + "", Toast.LENGTH_SHORT).show();

	}

    private boolean isMyServiceRunning(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}

	public static void aiload(Context c)throws Exception {
		Thread.sleep(10000);
		if (battry(c) > 11) {int ths=c.getSharedPreferences("deti", c.MODE_PRIVATE).getInt("thresh", 0);
			if (Applications.createShells.ishmp()) {Shell.sudo("echo interactive > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");
				String pa="/sys/devices/system/cpu/cpufreq/interactive/";
				Shell.sudo("echo 20000 " + avfreq(0)[avfreq(0).length] + ":60000 " + avfreq(0)[avfreq(0).length - 2] + ":150000 >" + pa + "above_highspeed_delay");
			} else {Shell.sudo("echo schedutil > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor");}
			if (islowmem(c)) {Applications.createShells.ka(c);}
			if (battry(c) < 11) {Applications.createShells.battry(c); return;} else {Shell.sudo("echo 1 > /sys/devives/system/cpu/cpu*/online");if (Applications.createShells.ishmp()) {Shell.sudo("echo \"interactive\" > /sys/devices/system/cpu/cpufreq/policy*/scaling_governer ");} else {Shell.sudo("echo \"schedutil\" > /sys/devices/system/cpu/cpufreq/policy*/scaling_governer ");}}
			if (cpuload() > 60) {if (cpuload() > 85) {
					Applications.createShells.setcpufreq(avfreq(0)[0], 0);
					Applications.createShells.setcpufreq(avfreq(1)[0], 1);
					Applications.createShells.setcpufreq(avfreq(2)[0], 2);
				}
				Applications.createShells.setcpufreq(avfreq(0)[avfreq(0).length * (((int)(100 - cpuload())) / 100) + ths], 0);
				Applications.createShells.setcpufreq(avfreq(2)[avfreq(2).length * (((int)(100 - cpuload())) / 100) + ths], 2);
				Applications.createShells.setcpufreq(avfreq(1)[avfreq(1).length * (((int)(100 - cpuload())) / 100) + ths], 1);
			} else {
				Applications.createShells.setcpufreq(avfreq(0)[avfreq(0).length], 0);
				Applications.createShells.setcpufreq(avfreq(1)[avfreq(1).length], 1);
				Applications.createShells.setcpufreq(avfreq(2)[avfreq(2).length], 2);
			}
//			if (gpuload() >= 40) {
//				Applications.createShells.setgpufreq(500000, true, c);
//			} else {
//				Applications.createShells.setgpufreq(200000, false, c);
//			}
		} else {Applications.createShells.battry(c);}
    }
	static  float cpuload() {
        String s="cat /proc/stat |grep cpu |tail -1|awk '{print ($5*100)/($2+$3+$4+$5+$6+$7+$8+$9+$10)}'|awk '{print 100-$1}'";
        try {
			return Float.parseFloat(Shell.sudo(s));
        } catch (Shell.ShellException e) {}
        return 0;
    }
	static  int battry(Context context) {BatteryManager bm = (BatteryManager) context.getSystemService(context.BATTERY_SERVICE);
        int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
		return batLevel;  }
	public static float gpuload() {
		try {String pvr=Shell.sudo("cat /sys/kernel/debug/pvr/status | tail -n1 | sed 's/.*GPU Utilisation://'");return Float.parseFloat(pvr.replace("%", ""));} catch (Exception e) {try {String ardeno[]=Shell.sudo("cat /sys/class/kgsl/kgsl*/gpubusy").split(" ");return Float.parseFloat(ardeno[0]) / Float.parseFloat(ardeno[1]);} catch (Exception e1) {try {String mali=Shell.sudo("cat /sys/devices/platform/mali*/devfreq/*gpu/load");return Float.parseFloat(mali);} catch (Exception e2) {try {String mali=Shell.sudo("cat /sys/devices/*mali/utilization");return Float.parseFloat(mali);} catch (Exception e3) {}}}}
		return 0;
	}
	static  boolean islowmem(Context c) {
		MemoryInfo mi = new MemoryInfo();
		ActivityManager activityManager = (ActivityManager)c.getSystemService(c.ACTIVITY_SERVICE);
		activityManager.getMemoryInfo(mi);
		int availableMegs = (int)(mi.totalMem / 0x100000L);
		return availableMegs < 220;
	}
	static  boolean isheat() throws Exception {
		float f= Float.parseFloat(Shell.sudo("cat /sys/class/thermal/thermal_zone0/temp")) / 1000;
        return f > 50;
    }
	public static String[] avfreq(int clust) throws Exception {
		String[] clus=Shell.sudo("ls -d /sys/devices/system/cpu/cpufreq/policy*").split("\\r?\\n");
		return Shell.sudo("cat " + clus[clust] + "/scaling_available_frequencies").split(" ");
	}
}
