package f00l.r;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import f00l.r.MainActivity;
import java.util.Random;

public class MainActivity extends Activity { 
	public EditText e;
	public TextView t;
	public WebView w;
	TextToSpeech tts;
	Shiomi shiomi;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//if(!permiss()){Toast.makeText(getApplication(), "Permissions not granted", Toast.LENGTH_SHORT).show();finishAndRemoveTask();}
		permiss();
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		setContentView(R.layout.activity_main);
		if (new Random().nextBoolean()) {v();}
		e = findViewById(R.id.activity_mainEditText);
		t = findViewById(R.id.activity_mainTextView);
		w = findViewById(R.id.activity_mainWebView);
		final View buty=findViewById(R.id.activity_mainButton);
		try {
			tts = new TextToSpeech(this, new TextToSpeech.OnInitListener(){

					@Override
					public void onInit(int p1) {
						if (p1 != TextToSpeech.ERROR) {
						}
					}
				});

		} catch (Exception e) {}

		String[] s={"Hi...","Whatsup? 😙","Yo! 😎","Hello 👋","😘","Hey howdy,Hi! ","What’s crackin’?","Bonjour😁","Hola😜","Hey buddy!😉"};
		int r=new Random().nextInt(s.length);
		t.setText(s[r]);
		

		final ToggleButton too=findViewById(R.id.activitymainImageButton124);
		SpannableStringBuilder sp=new SpannableStringBuilder(" ");
		Drawable mic =getResources().getDrawable(R.drawable.google_voice_search);
		mic.setBounds(0, 0, too.getLineHeight(), too.getLineHeight());
		sp.setSpan(new ImageSpan(mic), sp.length() - 1, sp.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
		too.setText(sp, ToggleButton.BufferType.SPANNABLE);
		too.setTextOn(sp);
		too.setTextOff(sp);

		new Handler().post(new Runnable(){

				@Override
				public void run() {
					shiomi= new Shiomi(e, t, w, MainActivity.this, buty);
					SetupWebView(w);
					if (getIntent().getExtras() != null) {if (getIntent().getExtras().getBoolean("note")) {e.setText("Note");shiomi.print();}}

					findViewById(R.id.expand).setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1) {
								startActivity(new Intent(MainActivity.this, bacteria.class));finish();
							}
						});
					
					buty.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1) {

								shiomi.print();
								if (e.getText().toString().isEmpty()) {
									if (too.isChecked()) {
										try {
											tts.speak(t.getText().toString(), TextToSpeech.QUEUE_ADD, null);
										} catch (Exception e) {}}
								}

							}
						});

				}
			});
	}

	private void permiss(){
		String[] permissions={Manifest.permission.RECORD_AUDIO,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE};
		
		if(checkCallingOrSelfPermission(Manifest.permission.RECORD_AUDIO)!=getPackageManager().PERMISSION_GRANTED){
			requestPermissions(permissions,1000);
			finish();
		}
		if(checkCallingOrSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!=getPackageManager().PERMISSION_GRANTED){
			requestPermissions(permissions,1000);finish();
		}
		if(!Settings.System.canWrite(this)){Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
				intent.setData(Uri.parse("package:" + this.getPackageName()));
				startActivity(intent);Toast.makeText(getApplication(), "Writing setting perpission not granted", Toast.LENGTH_SHORT).show();finish();}
			if(!Settings.canDrawOverlays(this)){  Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,	
																			 Uri.parse("package:" + getPackageName()));
				startActivityForResult(intent, 2084);
				startActivity(intent);Toast.makeText(getApplication(), "Overlay permission not granted", Toast.LENGTH_SHORT).show();finish();}
			
	}

	void v() {AlertDialog dialog = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_NoActionBar)
			.setTitle("Become a insider")
			.setMessage("Join our telegram group for more tips & trick about G-A.ME and find out more features. G-A.ME can be a way lot better for you and because of you..Thanks")
			.setPositiveButton("Join", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dia, int which) {
					pee.telg(MainActivity.this);
				}
			})
			.create();
		if (!((Activity)this).isFinishing()) {dialog.show();}}


	@Override
	protected void onResume() {
		super.onResume();
		SharedPreferences str=getSharedPreferences(getApplicationInfo().name, MODE_PRIVATE);
		if (str.getBoolean(getApplicationInfo().name, true)) {
			startActivity(new Intent(this, emty.class));
			str.edit().putBoolean(getApplicationInfo().name, false).apply();
		}
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
							 WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
							 WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
							 WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

	}

	void SetupWebView(WebView wv) {
		WebSettings wvs=wv.getSettings();
		wv.setWebViewClient(new WebViewClient());
		wvs.setJavaScriptCanOpenWindowsAutomatically(true);
		wvs.setJavaScriptEnabled(true);
		wvs.setAllowContentAccess(true);
		wvs.setAllowFileAccess(true);
		wvs.setDatabaseEnabled(true);
		wvs.setDomStorageEnabled(true);
		wvs.setUseWideViewPort(false);
		wvs.setSupportZoom(true);
		wvs.setBuiltInZoomControls(true);
		wvs.setUserAgentString(new WebView(this).getSettings().getUserAgentString());
		wvs.setDisplayZoomControls(false);
		wv.setScrollBarStyle(33554432);
		wv.setScrollbarFadingEnabled(true);
		wvs.enableSmoothTransition();
		wvs.getAllowUniversalAccessFromFileURLs();
		wvs.getCacheMode();
		wvs.getBlockNetworkLoads();
		wvs.getMediaPlaybackRequiresUserGesture();
		wvs.getOffscreenPreRaster();
		wvs.setMixedContentMode(0);
		wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
	}

	public void esteregg(View v){
		Intent i= new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/0-Whoami/G-A.ME/"));
		startActivity(i);
	}
} 
