package f00l.r;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class map extends Activity {
    TextView t;
	int[] xy=new int[2];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
	    t=findViewById(R.id.wTextView);
		int X,Y;
		SharedPreferences p1=getSharedPreferences("a",MODE_PRIVATE);
		X=p1.getInt("tapX",0);Y=p1.getInt("tapY",0);
		t.animate().x(X).y(Y).setDuration(0);
		new Handler().postDelayed(new Runnable(){

				@Override
				public void run() {
					t.getLocationOnScreen(xy);
					t.setText("➕"+"\n"+xy[0]+" "+xy[1]);
				}
			}, 200);
		findViewById(R.id.wRelativeLayout).setBackground(getWallpaper().mutate());
		t.setOnTouchListener(new View.OnTouchListener(){
				float dX, dY;
				@Override
				public boolean onTouch(View view, MotionEvent event) {

					switch (event.getAction()) {

						case MotionEvent.ACTION_DOWN:

							dX = view.getX() - event.getRawX();
							dY = view.getY() - event.getRawY();
							break;

						case MotionEvent.ACTION_MOVE:

							view.animate()
								.x(event.getRawX() + dX)
								.y(event.getRawY() + dY)
								.setDuration(0)
								.start();
							t.getLocationOnScreen(xy);
							t.setText("➕"+"\n"+xy[0]+" "+xy[1]);
								return true;
					}
					return true;
				}
			});
			
    }
	@Override
	public void onBackPressed() {
		//getSharedPreferences("a",MODE_PRIVATE).edit().putString("tap",""+xy[0]+" "+xy[1]).apply();
		super.onBackPressed();
	}
}
